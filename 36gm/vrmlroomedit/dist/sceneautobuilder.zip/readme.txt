SceneAutoBuilder
****************

v1.1 (c) Petr Kadlec, 2002-2003

Ke spu�t�n� pou�ijte d�vku BuildScene.bat, nap�. takto:
BuildScene sc�na.xml v�stup.wrl

Dal�� podrobnosti hledejte v dokumentaci, viz docs\index.htm
