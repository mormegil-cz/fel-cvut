package cz.cvut.felk.cs.gm.sceneautobuilder;

/**
 * Title:        Stavebnice komplexnich 3D scen
 * Description:
 * Copyright:    Copyright (c) 2002
 * Company:
 * @author Petr Kadlec <kadlecp2@fel.cvut.cz>
 * @version 1.1
 */

import java.util.List;
import java.util.Iterator;

import org.xml.sax.ContentHandler;
import org.xml.sax.ErrorHandler;
import org.xml.sax.Attributes;
import org.xml.sax.XMLReader;
import org.xml.sax.helpers.XMLReaderFactory;
import org.xml.sax.Locator;
import org.xml.sax.SAXException;
import org.xml.sax.SAXParseException;
import org.xml.sax.InputSource;

/**
 * An exception class for reporting errors in library XML file.
 * This exception is usually wrapped into a SAXException when thrown.
 */
class InvalidLibrary extends Exception {
  /**
   * The default constructor.
   * @see Exception#Exception()
   */
  public InvalidLibrary() {
    super();
  }

  /**
   * This constructor creates this exception with the associated error message.
   * @param msg The error message.
   * @see Exception#Exception(String)
   */
  public InvalidLibrary(String msg) {
    super(msg);
  }

  /**
   * This constructor adds the error location to the error message.
   * @param msg The error message.
   * @param locator The Locator object specifying the error position.
   */
  public InvalidLibrary(String msg, Locator locator) {
    super("("+locator.getLineNumber()+":"+locator.getColumnNumber()+") "+msg);
  }

  /**
   * This is a utility function that create a new InvalidLibrary object,
   * using the appropriate constructor &ndash; when the locator is not null,
   * it is used to report the error position.
   * @param msg The error message.
   * @param locator The Locator object, or null if no Locator is available.
   * @see #InvalidLibrary(String)
   * @see #InvalidLibrary(String,Locator)
   */
  public static InvalidLibrary create(String msg, Locator locator) {
    if (locator == null) return new InvalidLibrary(msg);
    else return new InvalidLibrary(msg, locator);
  }
}

/**
 * This class is a container for the description of a single portal.
 */
class PortalDescription {
  /**
   * Value of the <CODE>type</CODE> attribute. This attribute contains the
   * portal type (e.g. "door", "window").
   */
  public String type;
  /**
   * Value of the <CODE>kind</CODE> attribute. This attribute contains the
   * portal kind (e.g. "in", "out").
   */
  public String kind;
  /**
   * Value of the <CODE>xpos</CODE> attribute. This attribute contains the
   * X coordinate of the portal.
   */
  public int xPos;
  /**
   * Value of the <CODE>ypos</CODE> attribute. This attribute contains the
   * Y coordinate of the portal.
   */
  public int yPos;
  /**
   * Value of the <CODE>zpos</CODE> attribute. This attribute contains the
   * Z coordinate of the portal.
   */
  public int zPos;

  //--------------

  /** Portal type identifier. These constants may not be modified. */
  public final static short PORTAL_INVALID = -1,
                            PORTAL_HDOOR = 0,
                            PORTAL_VDOOR = 1,
                            PORTAL_HWINDOW = 2,
                            PORTAL_VWINDOW = 3,
                            PORTAL_USTAIRS = 4,
                            PORTAL_DSTAIRS = 5,
                            PORTAL_UDSTAIRS = 6;

  /** Portal kind identifier */
  public final static short PORTAL_IN = PlatformCell.PORTAL_IN,
                            PORTAL_OUT = PlatformCell.PORTAL_OUT,
                            PORTAL_INOUT = PlatformCell.PORTAL_INOUT;

  /** Portal type according to the {@link #type} field. Contains one of the PORTAL_xxx values. */
  public short portal_type;

  /** Portal kind according to the {@link #kind) field. Contains on of the PORTAL_xxx values. */
  public short portal_kind;

  //--------------

  /** The default constructor. */
  public PortalDescription() {}

  /**
   * This constructor creates the object and fills the values from the
   * <CODE>portal</CODE> tag's attributes.
   * @param atts Attributes containing the <CODE>portal</CODE> tag's attributes
   * @throws InvalidLibrary when an attribute has an invalid value.
   * @throws NumberFormatException when values of the numerical attributes
   *                               do not have a valid format.
   */
  public PortalDescription(Attributes atts) throws InvalidLibrary {
    type = atts.getValue("type");
    kind = atts.getValue("kind");
    xPos = Integer.parseInt(atts.getValue("xpos"));
    yPos = Integer.parseInt(atts.getValue("ypos"));
    zPos = Integer.parseInt(atts.getValue("zpos"));

    if (xPos < 0 || yPos < 0 || zPos < 0)
      throw new InvalidLibrary("Invalid portal position");

    if (type.equalsIgnoreCase("hdoor")) portal_type = PORTAL_HDOOR;
    else if (type.equalsIgnoreCase("vdoor")) portal_type = PORTAL_VDOOR;
    else if (type.equalsIgnoreCase("hwindow")) portal_type = PORTAL_HWINDOW;
    else if (type.equalsIgnoreCase("vwindow")) portal_type = PORTAL_VWINDOW;
    else if (type.equalsIgnoreCase("ustairs")) portal_type = PORTAL_USTAIRS;
    else if (type.equalsIgnoreCase("dstairs")) portal_type = PORTAL_DSTAIRS;
    else if (type.equalsIgnoreCase("udstairs")) portal_type = PORTAL_UDSTAIRS;
    else throw new InvalidLibrary("Invalid portal type");

    if (kind.equalsIgnoreCase("in")) portal_kind = PORTAL_IN;
    else if (kind.equalsIgnoreCase("out")) portal_kind = PORTAL_OUT;
    else if (kind.equalsIgnoreCase("inout")) portal_kind = PORTAL_INOUT;
    else throw new InvalidLibrary("Invalid portal kind");
  }

  /**
   * This method returns a string description of this object.
   * @return A string describing this object.
   * @see Object#toString()
   */
  public String toString() {
    return type + " (" + kind + ") [" + xPos + "; " + yPos + "; " + zPos + "]";
  }
}

/**
 * This class is a container for the description of a single room constraint.
 * @see SceneReqConstraint
 */
class RoomConstraint {
  /**
   * Value of the <CODE>type</CODE> attribute. This attribute contains the
   * type of the constraint.
   */
  public String type;
  /**
   * Value of the <CODE>function</CODE> attribute. This attribute contains the
   * constraining function.
   */
  public String function;
  /**
   * Value of the <CODE>value</CODE> attribute. This attribute contains the
   * constraining value. The value of Float.NaN means that this attribute was
   * omitted in the tag.
   */
  public float value;
  /**
   * Value of the <CODE>from</CODE> attribute. This attribute contains the
   * name of the related room/group.
   */
  public String from;
  /**
   * Value of the <CODE>score</CODE> attribute. This attribute contains the
   * score modifier of this constraint.
   */
  public float score;

  /** Constraint type (one of the CONSTRAINT_TYPE_xxx constants) */
  public short constraintType;
  /** Constraint function (one of the CONSTRAINT_FUNCTION_xxx constants) */
  public short constraintFunction;

  /** Constraint function constant */
  public static final short
    CONSTRAINT_FUNCTION_INVALID = -1,
    CONSTRAINT_FUNCTION_MIN = 0,
    CONSTRAINT_FUNCTION_MAX = 1,
    CONSTRAINT_FUNCTION_LINEAR = 2,
    CONSTRAINT_FUNCTION_YES = 3,
    CONSTRAINT_FUNCTION_NO = 4,
    CONSTRAINT_FUNCTION_EQUALS = 5;
  private static final short
    MAX_CONSTRAINT_FUNCTION = 5;

  /** Constraint type constant */
  public static final short
    CONSTRAINT_TYPE_INVALID = -1,
    CONSTRAINT_TYPE_DISTANCE = 0,
    CONSTRAINT_TYPE_NEIGHBOUR = 1,
    CONSTRAINT_TYPE_CONNECTED = 2;
  private static final short
    MAX_CONSTRAINT_TYPE = 2;

  private static final String[] constraintTypeIds = { "distance", "neighbour", "connected" };
  private static final String[] constraintFunctionIds = { "min", "max", "linear", "yes", "no", "equals" };

  /** The default constructor. */
  public RoomConstraint() {}

  /**
   * This constructor creates the object and fills the values from the
   * <CODE>constraint</CODE> tag's attributes.
   * @param atts Attributes containing the <CODE>constraint</CODE> tag's attributes
   * @throws NumberFormatException when values of the numerical attributes
   *                               do not have a valid format.
   * @throws InvalidLibrary when the value of some attribute is invalid.
   */
  public RoomConstraint(Attributes atts) throws InvalidLibrary {
    type = atts.getValue("type");
    function = atts.getValue("function");
    if (atts.getIndex("value") < 0) {
      value = Float.NaN;
    } else {
      value = Float.parseFloat(atts.getValue("value"));
    }
    from = atts.getValue("from");
    if (atts.getIndex("score") < 0) {
      score = Float.POSITIVE_INFINITY;
    } else {
      score = Float.parseFloat(atts.getValue("score"));
    }

    if (type == null || function == null || from == null)
      throw new InvalidLibrary("Required room constraint attribute missing");

    short i;
    constraintType = CONSTRAINT_TYPE_INVALID;
    for (i = 0; i <= MAX_CONSTRAINT_TYPE; i++)
      if (type.equalsIgnoreCase(constraintTypeIds[i])) {
        constraintType = i;
        break;
      }
    if (constraintType == CONSTRAINT_TYPE_INVALID)
      throw new InvalidLibrary("Invalid constraint type ('"+type+"')");

    constraintFunction = functionNameToId(function);
    switch (constraintFunction) {
      case CONSTRAINT_FUNCTION_INVALID:
        throw new InvalidLibrary("Invalid constraint function ('"+function+"')");

      case CONSTRAINT_FUNCTION_LINEAR:
        if (Float.isNaN(value)) value = 0;
        break;

      case CONSTRAINT_FUNCTION_MIN:
      case CONSTRAINT_FUNCTION_MAX:
      case CONSTRAINT_FUNCTION_EQUALS:
        if (Float.isNaN(value))
          throw new InvalidLibrary("Constraining value expected for the "+function+" function");
        break;

      case CONSTRAINT_FUNCTION_YES:
      case CONSTRAINT_FUNCTION_NO:
        if (!Float.isNaN(value))
          throw new InvalidLibrary("The "+function+" function may not have a constraining value");
        break;
    }
  }

  /**
   * Helper function for conversion of function name (String) to its Id (short).
   * @param name The function name.
   * @return The function identifier (one of CONSTRAINT_FUNCTION_xxx), CONSTRAINT_FUNCTION_INVALID
   *         if the name is unknown.
   */
  static short functionNameToId(String name) {
    for (short i = 0; i <= MAX_CONSTRAINT_FUNCTION; i++)
      if (name.equalsIgnoreCase(constraintFunctionIds[i]))
        return i;

    return CONSTRAINT_FUNCTION_INVALID;
  }

  /**
   * This helper method computes the value of the constraint function.
   * @param constraintFunction The function specifier (one of CONSTRAINT_FUNCTION_xxx constants).
   * @param arg The argument for the function.
   * @param value The reference value.
   * @return Result of the function applied to the arg &ndash; constraintFunction[value](arg).
   */
  static float evaluateFunction(short constraintFunction, float arg, float value) {
    switch (constraintFunction) {
      case CONSTRAINT_FUNCTION_LINEAR:
        return arg - value;

      case CONSTRAINT_FUNCTION_MIN:
        if (arg < value) return -1;
        else return 0;

      case CONSTRAINT_FUNCTION_MAX:
        if (arg > value) return -1;
        else return 0;

      case CONSTRAINT_FUNCTION_YES:
        if (arg == 0) return -1;
        else return 0;

      case CONSTRAINT_FUNCTION_NO:
        if (arg == 0) return 0;
        else return -1;

      case CONSTRAINT_FUNCTION_EQUALS:
        if (arg == value) return 0;
        else return -1;

      default:
        throw new AssertionFailure("Invalid constraintFunction");
    }
  }

  /**
   * This is a helper method that computes a*b with special infinity handling
   * that is to be used when multiplying score values.
   * @return 0 for 0*infinity, a*b otherwise
   */
  static float multiplyScore(float a, float b) {
    if ((Float.isInfinite(a) && b == 0) ||
        (Float.isInfinite(b) && a == 0)) return 0;
    else return a * b;
  }

  /**
   * This method computes the value of this constraint for a pair of rooms.
   * @param room A room that has specified this constraint.
   * @param refRoom A room that is described in the <CODE>from</CODE> attribute.
   * @return Score of the constraint when applied to the specified rooms.
   */
  public float evaluate(RoomPlacement room, RoomPlacement fromRoom) {
    switch (constraintType) {
      case CONSTRAINT_TYPE_DISTANCE: {
        float distance = (float)Math.sqrt(Math.pow(room.xo - fromRoom.xo + (room.roomCompilation.xSize - fromRoom.roomCompilation.xSize)/2.0,2) +
                                          Math.pow(room.yo - fromRoom.yo + (room.roomCompilation.ySize - fromRoom.roomCompilation.ySize)/2.0,2) +
                                          Math.pow(room.zo - fromRoom.zo + (room.roomCompilation.zSize - fromRoom.roomCompilation.zSize)/2.0,2));

        return multiplyScore(score, evaluateFunction(constraintFunction, distance, value));
      }

      case CONSTRAINT_TYPE_NEIGHBOUR: {
        // 1. check bounding boxes
        if (room.xo + room.roomCompilation.xSize < fromRoom.xo ||
            room.yo + room.roomCompilation.ySize < fromRoom.yo ||
            room.zo + room.roomCompilation.zSize < fromRoom.zo ||
            fromRoom.xo + fromRoom.roomCompilation.xSize < room.xo ||
            fromRoom.yo + fromRoom.roomCompilation.ySize < room.yo ||
            fromRoom.zo + fromRoom.roomCompilation.zSize < room.zo)
            return multiplyScore(score, evaluateFunction(constraintFunction, 0, value));

        // 2. do a per-cell check
        int xc0 = (room.xo - 1 <= fromRoom.xo) ?  fromRoom.xo : room.xo - 1,
            yc0 = (room.yo - 1 <= fromRoom.yo) ?  fromRoom.yo : room.yo - 1,
            zc0 = (room.zo - 1 <= fromRoom.zo) ?  fromRoom.zo : room.zo - 1,
            xc1 = (room.xo + room.roomCompilation.xSize <= fromRoom.xo + fromRoom.roomCompilation.xSize - 1) ? room.xo + room.roomCompilation.xSize : fromRoom.xo + fromRoom.roomCompilation.xSize - 1,
            yc1 = (room.yo + room.roomCompilation.ySize <= fromRoom.yo + fromRoom.roomCompilation.ySize - 1) ? room.yo + room.roomCompilation.xSize : fromRoom.yo + fromRoom.roomCompilation.ySize - 1,
            zc1 = (room.zo + room.roomCompilation.zSize <= fromRoom.zo + fromRoom.roomCompilation.zSize - 1) ? room.zo + room.roomCompilation.xSize : fromRoom.zo + fromRoom.roomCompilation.zSize - 1;

        for (int z = zc0; z <= zc1; z++) {
          int zr = z - room.zo,
              zfr = z - fromRoom.zo;
          for (int y = yc0; y <= yc1; y++) {
            int yr = y - room.yo,
                yfr = y - fromRoom.yo;
            for (int x = xc0; x <= xc1; x++) {
              int xr = x - room.xo,
                  xfr = x - fromRoom.xo;

              if (xr >= 0 && xr < room.roomCompilation.xSize &&
                  yr >= 0 && yr < room.roomCompilation.ySize &&
                  zr >= 0 && zr < room.roomCompilation.zSize &&
                  room.roomCompilation.platformCells[xr][yr][zr].available) {
                for (short s = 0; s < 6; s++) {
                  int xs = x + RoomPlacement.dxs[s] - fromRoom.xo,
                      ys = y + RoomPlacement.dys[s] - fromRoom.yo,
                      zs = z + RoomPlacement.dzs[s] - fromRoom.zo;
                  if (xs >= 0 && xs < fromRoom.roomCompilation.xSize &&
                      ys >= 0 && ys < fromRoom.roomCompilation.ySize &&
                      zs >= 0 && zs < fromRoom.roomCompilation.zSize &&
                      fromRoom.roomCompilation.platformCells[xs][ys][zs].available) {
                    return multiplyScore(score, evaluateFunction(constraintFunction, 1, value));
                  }
                }
              } else if (xfr >= 0 && xfr < fromRoom.roomCompilation.xSize &&
                         yfr >= 0 && yfr < fromRoom.roomCompilation.ySize &&
                         zfr >= 0 && zfr < fromRoom.roomCompilation.zSize &&
                         fromRoom.roomCompilation.platformCells[xfr][yfr][zfr].available) {
                for (short s = 0; s < 6; s++) {
                  int xs = x + RoomPlacement.dxs[s] - room.xo,
                      ys = y + RoomPlacement.dys[s] - room.yo,
                      zs = z + RoomPlacement.dzs[s] - room.zo;
                  if (xs >= 0 && xs < room.roomCompilation.xSize &&
                      ys >= 0 && ys < room.roomCompilation.ySize &&
                      zs >= 0 && zs < room.roomCompilation.zSize &&
                      room.roomCompilation.platformCells[xs][ys][zs].available) {
                    return multiplyScore(score, evaluateFunction(constraintFunction, 1, value));
                  }
                }
              }
            }
          }
        }

        // they are not neighbours
        return multiplyScore(score, evaluateFunction(constraintFunction, 0, value));
      }

      case CONSTRAINT_TYPE_CONNECTED: {
        // 1. check bounding boxes
        if (room.xo + room.roomCompilation.xSize < fromRoom.xo ||
            room.yo + room.roomCompilation.ySize < fromRoom.yo ||
            room.zo + room.roomCompilation.zSize < fromRoom.zo ||
            fromRoom.xo + fromRoom.roomCompilation.xSize < room.xo ||
            fromRoom.yo + fromRoom.roomCompilation.ySize < room.yo ||
            fromRoom.zo + fromRoom.roomCompilation.zSize < room.zo)
            return multiplyScore(score, evaluateFunction(constraintFunction, 0, value));

        // 2. do a per-cell check
        int xc0 = (room.xo - 1 <= fromRoom.xo) ?  fromRoom.xo : room.xo - 1,
            yc0 = (room.yo - 1 <= fromRoom.yo) ?  fromRoom.yo : room.yo - 1,
            zc0 = (room.zo - 1 <= fromRoom.zo) ?  fromRoom.zo : room.zo - 1,
            xc1 = (room.xo + room.roomCompilation.xSize <= fromRoom.xo + fromRoom.roomCompilation.xSize - 1) ? room.xo + room.roomCompilation.xSize : fromRoom.xo + fromRoom.roomCompilation.xSize - 1,
            yc1 = (room.yo + room.roomCompilation.ySize <= fromRoom.yo + fromRoom.roomCompilation.ySize - 1) ? room.yo + room.roomCompilation.xSize : fromRoom.yo + fromRoom.roomCompilation.ySize - 1,
            zc1 = (room.zo + room.roomCompilation.zSize <= fromRoom.zo + fromRoom.roomCompilation.zSize - 1) ? room.zo + room.roomCompilation.xSize : fromRoom.zo + fromRoom.roomCompilation.zSize - 1;

        for (int z = zc0; z <= zc1; z++) {
          int zr = z - room.zo,
              zfr = z - fromRoom.zo;
          for (int y = yc0; y <= yc1; y++) {
            int yr = y - room.yo,
                yfr = y - fromRoom.yo;
            for (int x = xc0; x <= xc1; x++) {
              int xr = x - room.xo,
                  xfr = x - fromRoom.xo;

              if (xr >= 0 && xr < room.roomCompilation.xSize &&
                  yr >= 0 && yr < room.roomCompilation.ySize &&
                  zr >= 0 && zr < room.roomCompilation.zSize &&
                  room.roomCompilation.platformCells[xr][yr][zr].available) {
                for (short s = 0; s < 4; s++) {
                  int xs = x + RoomPlacement.dxs[s] - fromRoom.xo,
                      ys = y + RoomPlacement.dys[s] - fromRoom.yo,
                      zs = z + RoomPlacement.dzs[s] - fromRoom.zo;
                  if ((room.roomCompilation.platformCells[xr][yr][zr].doors[s] | room.roomCompilation.platformCells[xr][yr][zr].windows[s]) != 0 &&
                      xs >= 0 && xs < fromRoom.roomCompilation.xSize &&
                      ys >= 0 && ys < fromRoom.roomCompilation.ySize &&
                      zs >= 0 && zs < fromRoom.roomCompilation.zSize &&
                      fromRoom.roomCompilation.platformCells[xs][ys][zs].available) {
                    return multiplyScore(score, evaluateFunction(constraintFunction, 1, value));
                  }
                }
                /** @todo connected via stairs */
                /*
                for (short s = 0; s < 2; s++) {
                  int xs = x + RoomPlacement.dxs[s] - fromRoom.xo,
                      ys = y + RoomPlacement.dys[s] - fromRoom.yo,
                      zs = z + RoomPlacement.dzs[s] - fromRoom.zo;
                  if ((room.roomCompilation.platformCells[xr][yr][zr].doors[s] | room.roomCompilation.platformCells[xr][yr][zr].windows[s]) != 0 &&
                      xs >= 0 && xs < fromRoom.roomCompilation.xSize &&
                      ys >= 0 && ys < fromRoom.roomCompilation.ySize &&
                      zs >= 0 && zs < fromRoom.roomCompilation.zSize &&
                      fromRoom.roomCompilation.platformCells[xs][ys][zs].available) {
                    return multiplyScore(score, evaluateFunction(constraintFunction, 1, value));
                  }
                }
                */
              } else if (xfr >= 0 && xfr < fromRoom.roomCompilation.xSize &&
                         yfr >= 0 && yfr < fromRoom.roomCompilation.ySize &&
                         zfr >= 0 && zfr < fromRoom.roomCompilation.zSize &&
                         fromRoom.roomCompilation.platformCells[xfr][yfr][zfr].available) {
                for (short s = 0; s < 4; s++) {
                  int xs = x + RoomPlacement.dxs[s] - room.xo,
                      ys = y + RoomPlacement.dys[s] - room.yo,
                      zs = z + RoomPlacement.dzs[s] - room.zo;
                  if ((fromRoom.roomCompilation.platformCells[xfr][yfr][zfr].doors[s] | fromRoom.roomCompilation.platformCells[xfr][yfr][zfr].windows[s]) != 0 &&
                      xs >= 0 && xs < room.roomCompilation.xSize &&
                      ys >= 0 && ys < room.roomCompilation.ySize &&
                      zs >= 0 && zs < room.roomCompilation.zSize &&
                      room.roomCompilation.platformCells[xs][ys][zs].available) {
                    return multiplyScore(score, evaluateFunction(constraintFunction, 1, value));
                  }
                }
                /** @todo connected via stairs */
              }
            }
          }
        }

        // they are not connected
        return multiplyScore(score, evaluateFunction(constraintFunction, 0, value));
      }

      default:
        throw new AssertionFailure("Invalid constraintType");
    }
  }

  /**
   * This method returns a string description of this object.
   * @return A string describing this object.
   * @see Object#toString()
   */
  public String toString() {
    return type + " " + function + " " + value + " " + from + " score = " + score;
  }
}

/**
 * This class contains internal compiled variables for a single room type
 * with a specified orientation (rotation).
 */
class RoomCompilation {
  /** RoomDescription to which this compilation belongs. */
  public RoomDescription room;

  /** X size of the room (rotated) */
  public int xSize;
  /** Y size of the room (rotated) */
  public int ySize;
  /** Z size of the room (rotated) */
  public int zSize;

  /** X coordinate of the first cell in this room */
  public int firstX;
  /** Y coordinate of the first cell in this room */
  public int firstY;
  /** Z coordinate of the first cell in this room */
  public int firstZ;

  /** Cells of the room platform */
  public PlatformCell[][][] platformCells;

  /** Rotate [x,y] in [xSize,ySize] rectangle */
  private int rotatedX(int x, int y, int xSize, int ySize, short rotation) {
    switch(rotation & 3) {
          case 0: return x;
          case 1: return ySize - 1 - y;
          case 2: return xSize - 1 - x;
          case 3: return y;
    }
    throw new AssertionFailure("rotatedX: rotation = "+rotation);
  }

  private int rotatedY(int x, int y, int xSize, int ySize, short rotation) {
    switch(rotation & 3) {
          case 0: return y;
          case 1: return x;
          case 2: return ySize - 1 - y;
          case 3: return xSize - 1 - x;
    }
    throw new AssertionFailure("rotatedY: rotation = "+rotation);
  }

  /** Rotate a portal */
  private PortalDescription rotatePortal(PortalDescription original, int origXSize, int origYSize, short rotation) {
    PortalDescription rotated = new PortalDescription();
    rotated.portal_kind = original.portal_kind;
    rotated.zPos = original.zPos;

    rotated.xPos = rotatedX(original.xPos, original.yPos, origXSize, origYSize, rotation);
    rotated.yPos = rotatedY(original.xPos, original.yPos, origXSize, origYSize, rotation);

    switch (original.portal_type) {
      case PortalDescription.PORTAL_USTAIRS:
      case PortalDescription.PORTAL_DSTAIRS:
      case PortalDescription.PORTAL_UDSTAIRS:
           rotated.portal_type = original.portal_type;
           break;

      case PortalDescription.PORTAL_HDOOR:
      case PortalDescription.PORTAL_HWINDOW:
           switch (rotation & 3) {
             case 2:
               rotated.yPos++;
               /* fall through */
             case 0:
               rotated.portal_type = original.portal_type;
               break;

             case 1:
               rotated.xPos++;
               /* fall through */
             case 3:
               rotated.portal_type = (short)(original.portal_type ^ 1);
               break;
           }
           break;

      case PortalDescription.PORTAL_VDOOR:
      case PortalDescription.PORTAL_VWINDOW:
           switch (rotation & 3) {
             case 2:
               rotated.xPos++;
               /* fall through */
             case 0:
               rotated.portal_type = original.portal_type;
               break;

             case 3:
               rotated.yPos++;
               /* fall through */
             case 1:
               rotated.portal_type = (short)(original.portal_type ^ 1);
               break;
           }
           break;
    }

    return rotated;
  }

  /**
   * Constructor. Creates the object, and fills its fields with values
   * derived from the parameters. All rotations of the platform + portals
   * happen here.
   * @param rotation How much is this room rotated
   * @param platform Boolean array containing the room platform's available flags.
   * @param portals List of portals in the room.
   */
  public RoomCompilation(short rotation, boolean[][][] platform, List portals) {
    boolean found = false;

    if ((rotation & 1) == 0) {
      xSize = platform.length;
      ySize = platform[0].length;
      zSize = platform[0][0].length;
    }
    else {
      xSize = platform[0].length;
      ySize = platform.length;
      zSize = platform[0][0].length;
    }

    platformCells = new PlatformCell[xSize][ySize][zSize];

    for (int x = 0; x < xSize; x++)
     for (int y = 0; y < ySize; y++)
      for (int z = 0; z < zSize; z++) {
       final int xOri = rotatedX(x, y, xSize, ySize, (short)(4-rotation)),
                 yOri = rotatedY(x, y, xSize, ySize, (short)(4-rotation));

       platformCells[x][y][z] = new PlatformCell(platform[xOri][yOri][z]);

       if (!found && platform[xOri][yOri][z]) {
         firstX = x;
         firstY = y;
         firstZ = z;
         found = true;
       }

       for (int s = 0; s < 4; s++) {
         platformCells[x][y][z].doors[s] = PlatformCell.PORTAL_NONE;
         platformCells[x][y][z].windows[s] = PlatformCell.PORTAL_NONE;
         if (s < 2) platformCells[x][y][z].stairs[s] = false;
       }
      }

    Iterator i = portals.iterator();
    while (i.hasNext()) {
      PortalDescription pOri = (PortalDescription) i.next();
      //System.out.println("Original portal: "+pOri);
      PortalDescription p = rotatePortal(pOri, platform.length, platform[0].length, rotation);
      //System.out.println("Rotated portal: "+p);
      final int x = p.xPos,
          y = p.yPos,
          z = p.zPos,
          hs = 0,
          hos = 2,
          vs = 3,
          vos = 1;

      switch (p.portal_type) {
        case PortalDescription.PORTAL_HDOOR:
             if (y < ySize)
               platformCells[x][y][z].doors[hs] = p.portal_kind;
             if (y > 0)
               platformCells[x][y-1][z].doors[hos] = p.portal_kind;
             break;

        case PortalDescription.PORTAL_VDOOR:
             if (x < xSize)
               platformCells[x][y][z].doors[vs] = p.portal_kind;
             if (x > 0)
               platformCells[x-1][y][z].doors[vos] = p.portal_kind;
             break;

        case PortalDescription.PORTAL_HWINDOW:
             if (y < ySize)
               platformCells[x][y][z].windows[hs] = p.portal_kind;
             if (y > 0)
               platformCells[x][y-1][z].windows[hos] = p.portal_kind;
             break;

        case PortalDescription.PORTAL_VWINDOW:
             if (x < xSize)
               platformCells[x][y][z].windows[vs] = p.portal_kind;
             if (x > 0)
               platformCells[x-1][y][z].windows[vos] = p.portal_kind;
             break;

        case PortalDescription.PORTAL_USTAIRS:
             platformCells[x][y][z].stairs[0] = true;
             break;
        case PortalDescription.PORTAL_UDSTAIRS:
             platformCells[x][y][z].stairs[0] = true;
             /* fall through! */
        case PortalDescription.PORTAL_DSTAIRS:
             platformCells[x][y][z].stairs[1] = true;
             break;
      }
    }
  }

  /**
   * Creates a string representation of this object.
   * @see Object#toString()
   */
  public String toString() {
    String pl = "";
    for (int z = 0; z < zSize; z++)
     for (int y = 0; y < ySize; y++) {
      for (int x = 0; x < xSize; x++) {
        if (platformCells[x][y][z].available) {
          int sides = 0;
          for (int s = 0; s < 4; s++)
            if (platformCells[x][y][z].doors[s] != PlatformCell.PORTAL_NONE) sides |= (1 << s);
          if (sides > 0) pl = pl + Integer.toHexString(sides);
          else pl = pl + 'X';
        } else pl = pl + ".";
      }
      pl = pl + "\n";
     }
    return pl;
  }
}

/**
 * This class is a container for the description of a single room type.
 */
class RoomDescription {
  /**
   * Value of the <CODE>object</CODE> attribute. This attribute contains the
   * identifier of the room's representation in the object library.
   */
  public String object;
  /**
   * Value of the <CODE>name</CODE> attribute. This attribute contains the
   * unique name of this room type.
   */
  public String name;
  /**
   * Value of the <CODE>group</CODE> attribute. This attribute contains the
   * identifier of the room group this room belongs to.
   */
  public String group;
  /**
   * Value of the <CODE>xsize</CODE> attribute. This attribute contains the
   * width of the room platform.
   */
  public int xSize;
  /**
   * Value of the <CODE>ysize</CODE> attribute. This attribute contains the
   * depth of the room platform.
   */
  public int ySize;
  /**
   * Value of the <CODE>zsize</CODE> attribute. This attribute contains the
   * height of the room platform.
   */
  public int zSize;

  /**
   * Content of the <CODE>description</CODE> tag. The tag contains a human-readable
   * textual description of the room type.
   */
  public String description;

  /**
   * Room platform definition. The array has dimensions of
   * <CODE>[{@link #xSize xSize}][{@link #ySize ySize}][{@link #zSize zSize}]</CODE>.
   * A value of true in a single cell means that this cell is inside the room.
   * A value of false means the respective cell is outside the room and another
   * room may be built there.
   */
  public boolean[][][] platform;

  /**
   * List of portals in this room. This List contains objects of the
   * {@link PortalDescription} type.
   */
  public List portals;
  /**
   * List of constraints related to this room. This List contains objects of the
   * {@link RoomConstraint} type.
   */
  public List constraints;

  //--------

  public RoomCompilation[] roomCompilations;

  /**
   * This constructor creates this objects and fills some of its data using the
   * attributes from the <CODE>room</CODE> tag.
   * @param atts The attributes from the <CODE>room</CODE> tag.
   * @throws InvalidLibrary when values of the attributes are illegal.
   * @throws NumberFormatException when values of the numerical attributes
   *                               do not have a valid format.
   */
  public RoomDescription(Attributes atts) throws InvalidLibrary {
    object = atts.getValue("object");
    if (atts.getIndex("name") < 0) {
      name = object;
    } else {
      name = atts.getValue("name");
    }
    if (atts.getIndex("group") < 0) {
      group = name;
    } else {
      group = atts.getValue("group");
    }
    xSize = Integer.parseInt(atts.getValue("xsize"));
    ySize = Integer.parseInt(atts.getValue("ysize"));
    zSize = Integer.parseInt(atts.getValue("zsize"));

    description = "";

    platform = new boolean[xSize][ySize][zSize];

    portals = new java.util.LinkedList();
    constraints = new java.util.LinkedList();
  }

  public void compile() {
    roomCompilations = new RoomCompilation[4];

    for (short rotation = 0; rotation < 4; rotation++)
      roomCompilations[rotation] = new RoomCompilation(rotation, platform, portals);
  }

  /**
   * This method returns a string description of this object.
   * @return A string describing this object.
   * @see Object#toString()
   */
  public String toString() {
    String pl = "";
    /*String pl = "\n";
    for (int r = 0; r < 4; r++) {
      pl = pl + "Room compilation["+r+"]:\n"+roomCompilations[r].toString()+"\n";
    }*/
    /*String pl = ":\n"";
    for (int z = 0; z < zSize; z++)
     for (int y = 0; y < ySize; y++) {
      for (int x = 0; x < xSize; x++)
       if (platform[x][y][z]) pl = pl + "X"; else pl = pl + ".";
      pl = pl + "\n";
     }*/
    //if (constraints.size() != 0) pl = " ("+constraints.size()+" constraints)" + pl;
    return name + " (object ID '" + object + "', group '" + group + "'), " + description + " " + xSize + "x" + ySize + "x" + zSize + pl;
  }
}

/**
 * This class is a container for the library description. The class implements
 * the ContentHandler interface so that it can be used directly to parse the XML
 * file containing the library description. This class implements also the
 * ErrorHandler interface so that it can itself also handle the errors when
 * parsing the XML file.
 */
class Library implements ContentHandler, ErrorHandler {
  /**
   * Value of the <CODE>URL</CODE> attribute of the root <CODE>library</CODE>
   * tag. This attribute specifies the object library that this document
   * describes.
   */
  public String URL;
  /**
   * Library scale. This are values of the <CODE>xscale, yscale, zscale</CODE>
   * attributes.
   */
  public float xScale, yScale, zScale;
  /**
   * Contents of the <CODE>description</CODE> tag.
   */
  public String description;

  /**
   * List of all rooms in the library. This list contains objects of the
   * {@link #RoomDescription RoomDescription} class.
   */
  public List rooms;

  /*------------------*/
  private int state;

  private Locator locator;

  private RoomDescription currRoom;
  private int level;
  private int currRow;
  private String rowData;
  /*------------------*/

  /*----------------------------- ContentHandler ---------------------------*/

  /**
   * No processing instructions are supported so that call of this method
   * results in an exception.
   * @see ContentHandler#processingInstruction(String,String)
   * @throws SAXException Immediately when this method is called.
   */
  public void processingInstruction(String target, String data) throws SAXException {
    throw new SAXException(InvalidLibrary.create("Processing instructions not allowed in library.", locator));
  }

  /**
   * Call of this method triggers an exception.
   * @see ContentHandler#skippedEntity(String)
   * @throws SAXException Immediately when this method is called.
   */
  public void skippedEntity(String name) throws SAXException {
    throw new SAXException(InvalidLibrary.create("Unknown entity", locator));
  }

  /**
   * We do not need any special processing for the prefix mapping, so we
   * do nothing in this method.
   * @see ContentHandler#startPrefixMapping(String,String)
   */
  public void startPrefixMapping(String prefix, String uri) {}

  /**
   * We do not need any special processing for the prefix mapping, so we
   * do nothing in this method.
   * @see ContentHandler#endPrefixMapping(String)
   */
  public void endPrefixMapping(String prefix) {}

  /**
   * Store the supplied document locator for possible later use.
   * @see ContentHandler#setDocumentLocator(Locator)
   */
  public void setDocumentLocator(Locator locator) {
    this.locator = locator;
  }

  /**
   * Initializes itself when parsing of a new XML document begins.
   * @see ContentHandler#startDocument()
   */
  public void startDocument() {
    description = "";

    rooms = new java.util.LinkedList();
  }

  /**
   * Processes an XML opening tag that has been read.
   * @see ContentHandler#startElement(String,String,String,Attributes)
   * @throws SAXException when some parsing error occurrs.
   */
  public void startElement(String namespaceURI, String localName, String qName,
                           Attributes atts) throws SAXException {
    try {
      switch(state) {
        case 0:
           if (!qName.equalsIgnoreCase("library"))
              throw InvalidLibrary.create("library expected but '"+qName+"' found", locator);

           URL = atts.getValue("URL");

           xScale = Float.parseFloat(atts.getValue("xscale"));
           if (atts.getIndex("yscale") < 0) {
             yScale = xScale;
           } else {
             yScale = Float.parseFloat(atts.getValue("yscale"));
           }
           if (atts.getIndex("zscale") < 0) {
             zScale = xScale;
           } else {
             zScale = Float.parseFloat(atts.getValue("zscale"));
           }

           state = 1;
           break;

        case 1:
          if (qName.equalsIgnoreCase("description")) {
            state = 2;
          } else if (qName.equalsIgnoreCase("room")) {
            currRoom = new RoomDescription(atts);
            rooms.add(currRoom);
            state = 3;
          } else throw InvalidLibrary.create("'"+qName+"' unexpected", locator);
          break;

        case 3:
          if (qName.equalsIgnoreCase("description")) {
            state = 4;
          } else if (qName.equalsIgnoreCase("platform")) {
            level = Integer.parseInt(atts.getValue("level"));
            currRow = 0;
            state = 5;
          } else if (qName.equalsIgnoreCase("allplatform")) {
            for (int x = 0; x < currRoom.xSize; x++)
             for (int y = 0; y < currRoom.ySize; y++)
              for (int z = 0; z < currRoom.zSize; z++)
                currRoom.platform[x][y][z] = true;

            state = 7;
          } else throw InvalidLibrary.create("'"+qName+"' unexpected", locator);
          break;

        case 5:
          if (!qName.equalsIgnoreCase("platformrow"))
            throw InvalidLibrary.create("platformrow expected but '"+qName+"' found", locator);

          if (currRow >= currRoom.ySize)
            throw InvalidLibrary.create("Too many platformrows", locator);

          rowData = "";
          state = 6;
          break;

        case 8:
          if (qName.equalsIgnoreCase("platform")) {
            level = Integer.parseInt(atts.getValue("level"));
            currRow = 0;
            state = 5;
          } else if (qName.equalsIgnoreCase("constraint")) {
            currRoom.constraints.add(new RoomConstraint(atts));
            state = 10;
          } else if (qName.equalsIgnoreCase("portal")) {
            currRoom.portals.add(new PortalDescription(atts));
            state = 9;
          } else throw InvalidLibrary.create("'"+qName+"' unexpected", locator);
          break;

        default:
          throw InvalidLibrary.create("'"+qName+"' unexpected", locator);
      }
    } catch (Exception e) {
      throw new SAXException(e);
    }
  }

  /**
   * Processes an XML closing tag that has been read.
   * @see ContentHandler#endElement(String,String,String)
   * @throws SAXException when some parsing error occurrs.
   */
  public void endElement(String namespaceURI, String localName, String qName) throws SAXException {
    try {
      switch(state) {
        case 1:
          if (!qName.equalsIgnoreCase("library"))
            throw InvalidLibrary.create("End of library expected but end of '"+qName+"' found", locator);
          state = 11;
          break;

        case 2:
          if (!qName.equalsIgnoreCase("description"))
            throw InvalidLibrary.create("End of description expected but end of '"+qName+"' found", locator);
          state = 1;
          break;

        case 4:
          if (!qName.equalsIgnoreCase("description"))
            throw InvalidLibrary.create("End of description expected but end of '"+qName+"' found", locator);
          state = 3;
          break;

        case 5:
          if (!qName.equalsIgnoreCase("platform"))
            throw InvalidLibrary.create("End of platform expected but end of '"+qName+"' found", locator);
          state = 8;
          break;

        case 6:
          if (!qName.equalsIgnoreCase("platformrow"))
            throw InvalidLibrary.create("End of platformrow expected but end of '"+qName+"' found", locator);

          rowData = rowData.trim();
          if (rowData.length() != currRoom.xSize)
            throw InvalidLibrary.create("Invalid platformrow (bad length)", locator);

          char[] rowChars = rowData.toCharArray();

          for (int x = 0; x < currRoom.xSize; x++) {
            switch (rowChars[x]) {
              case 'x':
              case 'X':
              case '1':
              case '#':
              case '*':
              case '+':
                currRoom.platform[x][currRow][level] = true;
                break;

              case '.':
              case '0':
              case ' ':
              case '-':
              case '_':
                currRoom.platform[x][currRow][level] = false;
                break;

              default:
                throw InvalidLibrary.create("Invalid platformrow (bad character)", locator);
            }
          }

          currRow++;
          state = 5;
          break;

        case 7:
          if (!qName.equalsIgnoreCase("allplatform"))
            throw InvalidLibrary.create("End of allplatform expected, but end of '"+qName+"' found", locator);

          state = 8;
          break;

        case 8:
          if (!qName.equalsIgnoreCase("room"))
            throw InvalidLibrary.create("End of room expected, but end of '"+qName+"' found", locator);
          currRoom.compile();
          state = 1;
          break;

        case 9:
          if (!qName.equalsIgnoreCase("portal"))
            throw InvalidLibrary.create("End of portal expected, but end of '"+qName+"' found", locator);
          state = 8;
          break;

        case 10:
          if (!qName.equalsIgnoreCase("constraint"))
            throw InvalidLibrary.create("End of constraint expected, but end of '"+qName+"' found", locator);
          state = 8;
          break;

        default:
          throw InvalidLibrary.create("End of '"+qName+" unexpected", locator);
      }
    } catch (Exception e) {
      e.printStackTrace();
      throw new SAXException(e);
    }
/*    } catch (InvalidLibrary e) {
      throw new SAXException(e);
    }*/
  }

  /**
   * Processes character data that has been read.
   * @see ContentHandler#characters(char[],int,int)
   * @throws SAXException when some parsing error occurrs.
   */
  public void characters(char[] ch, int start, int length) throws SAXException {
    try {
      switch(state) {
        case 2:
          description = description + String.copyValueOf(ch, start, length);
          break;

        case 4:
          currRoom.description = currRoom.description + String.copyValueOf(ch, start, length);
          break;

        case 6:
          rowData = rowData + String.copyValueOf(ch, start, length);
          break;

        default:
          throw InvalidLibrary.create("Unexpected character data", locator);
      }
    } catch (Exception e) {
      throw new SAXException(e);
    }
  }

  /**
   * Processes whitespace that has been read, but can be ignored.
   * @see ContentHandler#ignorableWhitespace(char[],int,int)
   * @throws SAXException when some parsing error occurrs.
   */
  public void ignorableWhitespace(char[] ch, int start, int length) throws SAXException {
    if (state == 2 || state == 4 || state == 6)
      characters(ch, start, length);
    // otherwise, ignore this whitespace
  }

  /**
   * Called when end of the XML document has been reached.
   * @see ContentHandler#endDocument()
   * @throws SAXException when some parsing error occurrs.
   */
  public void endDocument() throws SAXException {
    if (state != 11) {
      throw new SAXException(InvalidLibrary.create("Premature end of input file", locator));
    }
  }

  /*----------------------------- ErrorHandler ---------------------------*/

  /**
   * A potentially error situation has been detected. The method prints a
   * warning message on the error output and continues without error.
   * @see ErrorHandler#warning(SAXParseException)
   */
  public void warning(SAXParseException exception) throws SAXException {
    System.err.println("WARNING: "+exception);
  }

  /**
   * An error situation has been detected. The method throws an exception
   * describing the error situation.
   * @see ErrorHandler#error(SAXParseException)
   * @throws SAXException immediately when this method gets called.
   */
  public void error(SAXParseException exception) throws SAXException {
    throw new SAXException(exception);
  }

  /**
   * A fatal error situation has been detected. The method throws an exception
   * describing the error situation.
   * @see ErrorHandler#fatalError(SAXParseException)
   * @throws SAXException immediately when this method gets called.
   */
  public void fatalError(SAXParseException exception) throws SAXException {
    throw new SAXException(exception);
  }

  /*------------------------------- other --------------------------------*/

  /**
   * The default constructor. Creates an empty Library, the values must be
   * filled in later by an external source, or this object can be later used as
   * a ContentHandler (and possibly also as an ErrorHandler) when parsing
   * an XML document.
   */
  public Library() { }

  /**
   * Create the Library and load the specified XML document into it. This constructor
   * creates a XMLReader and parses the specified XML document using itself as
   * content and error handlers. The value of the "org.xml.sax.driver" property
   * specifies the XMLReader reader used to parse the document.
   * @param xmlFile URI of the top-level XML document to be parsed
   * @throws SAXException when parsing the XML document fails
   * @throws java.io.IOException an IO exception from the parser
   * @see XMLReader
   * @see XMLReaderFactory#createXMLReader()
   */
  public Library(String xmlFile) throws SAXException, java.io.IOException {
      XMLReader xmlReader = XMLReaderFactory.createXMLReader();
      xmlReader.setContentHandler(this);
      xmlReader.setErrorHandler(this);
      xmlReader.parse(xmlFile);
  }

  /**
   * Create the Library and load the specified XML file into it. This constructor
   * creates a XMLReader and parses the specified XML file using itself as
   * content and error handlers. The value of the "org.xml.sax.driver" property
   * specifies the XMLReader reader used to parse the file.
   * @param input The input source for the top-level of the XML document.
   * @throws SAXException when parsing the XML document fails
   * @throws java.io.IOException an IO exception from the parser
   * @see XMLReader
   * @see XMLReaderFactory#createXMLReader()
   */
  public Library(InputSource input) throws SAXException, java.io.IOException {
      XMLReader xmlReader = XMLReaderFactory.createXMLReader();
      xmlReader.setContentHandler(this);
      xmlReader.setErrorHandler(this);
      xmlReader.parse(input);
  }

  /**
   * This method returns a string description of this object.
   * @return A string describing this object.
   * @see Object#toString()
   */
  public String toString() {
    String s = "Room library:\nLibrary URL:\t'"+URL+"'\nDescription:\t"+description+"\nRooms:\n";
    int i;

    Object[] list;

    list = rooms.toArray();
    for (i = 0; i < list.length; i++)
      s = s + "\t" + (RoomDescription)(list[i]) + "\n";

    return s;
  }
}
