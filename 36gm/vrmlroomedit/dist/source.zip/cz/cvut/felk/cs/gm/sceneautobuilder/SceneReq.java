package cz.cvut.felk.cs.gm.sceneautobuilder;

/**
 * Title:        Stavebnice komplexnich 3D scen
 * Description:
 * Copyright:    Copyright (c) 2002
 * Company:
 * @author Petr Kadlec <kadlecp2@fel.cvut.cz>
 * @version 1.1
 */

import java.util.List;

import org.xml.sax.ContentHandler;
import org.xml.sax.ErrorHandler;
import org.xml.sax.XMLReader;
import org.xml.sax.InputSource;
import org.xml.sax.Attributes;
import org.xml.sax.Locator;
import org.xml.sax.helpers.DefaultHandler;
import org.xml.sax.helpers.XMLReaderFactory;
import org.xml.sax.SAXException;
import org.xml.sax.SAXParseException;

/**
 * An exception class for reporting errors in scene requirements XML file.
 * This exception is usually wrapped into a SAXException when thrown.
 */
class InvalidSceneReq extends Exception {
  /**
   * The default constructor.
   * @see Exception#Exception()
   */
  public InvalidSceneReq() {
    super();
  }

  /**
   * This constructor creates this exception with the associated error message.
   * @param msg The error message.
   * @see Exception#Exception(String)
   */
  public InvalidSceneReq(String msg) {
    super(msg);
  }

  /**
   * This constructor adds the error location to the error message.
   * @param msg The error message.
   * @param locator The Locator object specifying the error position.
   */
  public InvalidSceneReq(String msg, Locator locator) {
    super("("+locator.getLineNumber()+":"+locator.getColumnNumber()+") "+msg);
  }

  /**
   * This is a utility function that create a new InvalidSceneReq object,
   * using the appropriate constructor &ndash; when the locator is not null,
   * it is used to report the error position.
   * @param msg The error message.
   * @param locator The Locator object, or null if no Locator is available.
   * @see #InvalidSceneReq(String)
   * @see #InvalidSceneReq(String,Locator)
   */
  public static InvalidSceneReq create(String msg, Locator locator) {
    if (locator == null) return new InvalidSceneReq(msg);
    else return new InvalidSceneReq(msg, locator);
  }
}

/**
 * This class is a container for the specification of a single required room/group.
 * The required room is specified in the XML file using the
 * </CODE>reqroom</CODE> tag.
 */
class RequiredRoom {
  /**
   * Value of the <CODE>name</CODE> attribute. This attribute contains the
   * name of the room group that is required in the scene.
   */
  public String name;
  /**
   * Value of the <CODE>min</CODE> attribute. This attribute contains the minimal
   * required number of rooms from this group.
   */
  public int min;
  /**
   * Value of the <CODE>max</CODE> attribute. This attribute contains the maximal
   * allowed number of rooms from this group.
   */
  public int max;
  /**
   * Value of the <CODE>score</CODE> attribute. This attribute contains the
   * score penalty when the final scene does not fulfill this requirement.
   * The value must be nonnegative.
   */
  public float score;

  /**
   * The default constructor.
   */
  public RequiredRoom() {}

  /**
   * This constructor creates this objects and fills its data using the
   * attributes from the <CODE>reqroom</CODE> tag.
   * @param atts The attributes from the <CODE>reqroom</CODE> tag.
   * @throws InvalidSceneReq when values of the attributes are illegal.
   * @throws NumberFormatException when values of the numerical attributes
   *                               do not have a valid format.
   */
  public RequiredRoom(Attributes atts) throws InvalidSceneReq {
    name = atts.getValue("name");
    min = Integer.parseInt(atts.getValue("min"));

    if (atts.getIndex("max") < 0) {
      max = Integer.MAX_VALUE;
    } else {
      max = Integer.parseInt(atts.getValue("max"));
    }

    if (atts.getIndex("score") < 0) {
      score = Float.POSITIVE_INFINITY;
    } else {
      score = Float.parseFloat(atts.getValue("score"));
    }

    if (min < 1 || min > max || score < 0)
      throw new InvalidSceneReq("Invalid reqroom attributes");
  }

  /**
   * This method returns a string description of this object.
   * @return A string describing this object.
   * @see Object#toString()
   */
  public String toString() {
    return name+" ("+min+"--"+max+", score = "+score+")";
  }
}

/**
 * This class is a container for the specification of a single allowed room.
 * The allowed room is specified in the XML file using the
 * </CODE>allowroom</CODE> tag.
 */
class AllowedRoom {
  /**
   * Value of the <CODE>name</CODE> attribute. This attribute contains the
   * name of the room group that is allowed in the scene.
   */
  public String name;
  /**
   * Value of the <CODE>score</CODE> attribute. This attribute contains the
   * score modifier when using this room group.
   */
  public float score;

  /**
   * The default constructor.
   */
  public AllowedRoom() {}

  /**
   * This constructor creates this objects and fills its data using the
   * attributes from the <CODE>allowroom</CODE> tag.
   * @param atts The attributes from the <CODE>allowroom</CODE> tag.
   * @throws NumberFormatException when values of the numerical attributes
   *                               do not have a valid format.
   */
  public AllowedRoom(Attributes atts) throws InvalidSceneReq {
    name = atts.getValue("name");
    score = Float.parseFloat(atts.getValue("score"));
  }

  /**
   * This method returns a string description of this object.
   * @return A string describing this object.
   * @see Object#toString()
   */
  public String toString() {
    return name+" (score = "+score+")";
  }
}

/**
 * This class is a container for the specification of a single constraint on the
 * scene.
 * The constraint on the scene is specified in the XML file using the
 * </CODE>constraint</CODE> tag.
 */
class SceneReqConstraint {
  /**
   * Value of the <CODE>type</CODE> attribute. This attribute contains the
   * identifier of the value that is constrained.
   */
  public String type;
  /**
   * Value of the <CODE>function</CODE> attribute. This attribute contains the
   * identifier of the constraining function.
   */
  public String function;
  /**
   * Value of the <CODE>value</CODE> attribute. This attribute contains the
   * constraining value.
   */
  public float value;
  /**
   * Value of the <CODE>score</CODE> attribute. This attribute contains the
   * score modifier for this constraint.
   */
  public float score;

  /** Constraint type. One of the SCENE_CONSTRAINT_TYPE_xxx constants. */
  public short constraintType;

  /** Constraining function. One of the RoomConstraint.CONSTRAINT_FUNCTION_xxx constants. */
  public short constraintFunction;

  /** Constraint type constant */
  public static final short
    SCENE_CONSTRAINT_TYPE_INVALID = -1,
    SCENE_CONSTRAINT_TYPE_DOORSOUT = 0,
    SCENE_CONSTRAINT_TYPE_WINDOWSOUT = 1,
    SCENE_CONSTRAINT_TYPE_ROOMCOUNT = 2;
  private static final short
    MAX_SCENE_CONSTRAINT_TYPE = 2;

  private static final String[] constraintTypeIds = { "doorsout", "windowsout", "roomcount" };

  /**
   * The default constructor.
   */
  public SceneReqConstraint() {}

  /**
   * This constructor creates this objects and fills its data using the
   * attributes from the <CODE>constraint</CODE> tag.
   * @param atts The attributes from the <CODE>constraint</CODE> tag.
   * @throws NumberFormatException when values of the numerical attributes
   *                               do not have a valid format.
   * @throws InvalidSceneReq when some attribute has invalid value
   */
  public SceneReqConstraint(Attributes atts) throws InvalidSceneReq {
    type = atts.getValue("type");
    function = atts.getValue("function");
    value = Float.parseFloat(atts.getValue("value"));

    if (atts.getIndex("score") < 0) {
      score = Float.POSITIVE_INFINITY;
    } else {
      score = Float.parseFloat(atts.getValue("score"));
    }

    if (type == null || function == null || score < 0)
      throw new InvalidSceneReq("Invalid constraint attributes");

    short i;
    constraintType = SCENE_CONSTRAINT_TYPE_INVALID;
    for (i = 0; i <= MAX_SCENE_CONSTRAINT_TYPE; i++)
      if (type.equalsIgnoreCase(constraintTypeIds[i])) {
        constraintType = i;
        break;
      }
    if (constraintType == SCENE_CONSTRAINT_TYPE_INVALID)
      throw new InvalidSceneReq("Invalid constraint type ('"+type+"')");

    constraintFunction = RoomConstraint.functionNameToId(function);
    switch (constraintFunction) {
      case RoomConstraint.CONSTRAINT_FUNCTION_INVALID:
        throw new InvalidSceneReq("Invalid constraint function ('"+function+"')");

      case RoomConstraint.CONSTRAINT_FUNCTION_LINEAR:
        if (Float.isNaN(value)) value = 0;
        break;

      case RoomConstraint.CONSTRAINT_FUNCTION_MIN:
      case RoomConstraint.CONSTRAINT_FUNCTION_MAX:
      case RoomConstraint.CONSTRAINT_FUNCTION_EQUALS:
        if (Float.isNaN(value))
          throw new InvalidSceneReq("Constraining value expected for the "+function+" function");
        break;

      case RoomConstraint.CONSTRAINT_FUNCTION_YES:
      case RoomConstraint.CONSTRAINT_FUNCTION_NO:
        if (!Float.isNaN(value))
          throw new InvalidSceneReq("The "+function+" function may not have a constraining value");
        break;
    }
  }

  /**
   * This method computes the value of this constraint for a scene solution.
   * @param solution The solution for which should be the constraint computed.
   * @return Score of the constraint when applied to the specified solution.
   */
  public float evaluate(Solution solution) {
    switch (constraintType) {
      case SCENE_CONSTRAINT_TYPE_DOORSOUT:
           int doorsOut = 0;
           for (int z = 0; z < solution.sceneReq.zSize; z++)
            for (int y = -1; y <= solution.sceneReq.ySize; y++)
             for (int x = -1; x <= solution.sceneReq.xSize; x++) {
               if ((x < 0 || x == solution.sceneReq.xSize) && (y < 0 || y == solution.sceneReq.ySize)) continue;

               if (x < 0 || x == solution.sceneReq.xSize || y < 0 || y == solution.sceneReq.ySize ||
                   !solution.sceneReq.platform[x][y][z]) {

                  for (short s = 0; s < 4; s++) {
                    int xs = x + RoomPlacement.dxs[s];
                    int ys = y + RoomPlacement.dys[s];

                    if (xs >= 0 && xs < solution.sceneReq.xSize && ys >= 0 && ys < solution.sceneReq.ySize &&
                        solution.sceneReq.platform[xs][ys][z] &&
                        solution.sceneReq.platformCells[xs][ys][z].doors[(s+2)%4] != PlatformCell.PORTAL_NONE)
                       doorsOut++;
                  }
               }
             }
           //System.out.println("DoorsOut = "+doorsOut);
           return RoomConstraint.multiplyScore(score, RoomConstraint.evaluateFunction(constraintFunction, doorsOut, value));

      case SCENE_CONSTRAINT_TYPE_WINDOWSOUT:
           int windowsOut = 0;
           for (int z = 0; z < solution.sceneReq.zSize; z++)
            for (int y = -1; y <= solution.sceneReq.ySize; y++)
             for (int x = -1; x <= solution.sceneReq.xSize; x++) {
               if ((x < 0 || x == solution.sceneReq.xSize) && (y < 0 || y == solution.sceneReq.ySize)) continue;

               if (x < 0 || x == solution.sceneReq.xSize || y < 0 || y == solution.sceneReq.ySize ||
                   !solution.sceneReq.platform[x][y][z]) {

                  for (short s = 0; s < 4; s++) {
                    int xs = x + RoomPlacement.dxs[s];
                    int ys = y + RoomPlacement.dys[s];

                    if (xs >= 0 && xs < solution.sceneReq.xSize && ys >= 0 && ys < solution.sceneReq.ySize &&
                        solution.sceneReq.platform[xs][ys][z] &&
                        solution.sceneReq.platformCells[xs][ys][z].windows[(s+2)%4] != PlatformCell.PORTAL_NONE)
                       windowsOut++;
                  }
               }
             }
           //System.out.println("WindowsOut = "+windowsOut);
           return RoomConstraint.multiplyScore(score, RoomConstraint.evaluateFunction(constraintFunction, windowsOut, value));

      case SCENE_CONSTRAINT_TYPE_ROOMCOUNT:
        return RoomConstraint.multiplyScore(score, RoomConstraint.evaluateFunction(constraintFunction, solution.rooms.size(), value));

      default:
        throw new AssertionFailure("Invalid constraintType");
    }
  }

  /**
   * This method returns a string description of this object.
   * @return A string describing this object.
   * @see Object#toString()
   */
  public String toString() {
    return type+" "+function+" "+value+", score = "+score;
  }
}

/**
 * This class is a container for the scene requirements. The class implements
 * the ContentHandler interface so that it can be used directly to parse the XML
 * file containing the scene requirements. This class implements also the
 * ErrorHandler interface so that it can itself also handle the errors when
 * parsing the XML file.
 */
class SceneReq implements ContentHandler, ErrorHandler {
  /**
   * Value of the <CODE>library</CODE> attribute of the root
   * <CODE>scenereq</CODE> tag. This attribute specifies the name of the top-level
   * XML document containing the object library description.
   */
  public String library;
  /**
   * Contents of the <CODE>description</CODE> tag.
   */
  public String description;
  /**
   * Width of the scene. (Value of the <CODE>xsize</CODE> attribute of the
   * root <CODE>scenereq</CODE> tag.)
   */
  public int xSize;
  /**
   * Depth of the scene. (Value of the <CODE>ysize</CODE> attribute of the
   * root <CODE>scenereq</CODE> tag.)
   */
  public int ySize;
  /**
   * Height of the scene. (Value of the <CODE>zsize</CODE> attribute of the
   * root <CODE>scenereq</CODE> tag.)
   */
  public int zSize;
  /**
   * Bad score ({@see Solver#tooLowScore}). (Value of the <CODE>badscore</CODE> attribute of the
   * root <CODE>scenereq</CODE> tag.)
   */
  public float badScore;
  /**
   * Trash score ({@see Solver#trashScore}). (Value of the <CODE>trashscore</CODE> attribute of the
   * root <CODE>scenereq</CODE> tag.)
   */
  public float trashScore;
  /**
   * Good score ({@see Solver#goodScore}). (Value of the <CODE>goodscore</CODE> attribute of the
   * root <CODE>scenereq</CODE> tag.)
   */
  public float goodScore;
  /**
   * Scene platform definition. The array has dimensions of
   * <CODE>[{@link #xSize xSize}][{@link #ySize ySize}][{@link #zSize zSize}]</CODE>.
   * A value of true in a single cell means there may be a room built there.
   * A value of false means the respective cell is outside the scene and no
   * room may be built using the cell.
   */
  public boolean[][][] platform;

  /**
   * List of required rooms (specified using the <CODE>reqroom</CODE> tags).
   * This list contains objects of the {@link RequiredRoom RequiredRoom} class.
   */
  public List reqRooms;
  /**
   * List of allowed rooms (specified using the <CODE>allowroom</CODE> tags).
   * This list contains objects of the {@link AllowedRoom AllowedRoom} class.
   */
  public List allowedRooms;
  /**
   * List of scene constraints (specified using the <CODE>constraint</CODE> tags).
   * This list contains objects of the {@link SceneReqConstraint SceneReqConstraint} class.
   */
  public List constraints;

  /*------------------*/

  /** The scene platform (high level version) */
  public ScenePlatformCell[][][] platformCells;

  /** See {@link #findEmptyCell()} */
  public int emptyX;
  public int emptyY;
  public int emptyZ;

  /*------------------*/

  /** private variables */
  private int state;
  private int level;
  private int currRow;
  private String rowData;

  private Locator locator;

  /*------------------*/

  /*----------------------------- ContentHandler ---------------------------*/

  /**
   * No processing instructions are supported so that call of this method
   * results in an exception.
   * @see ContentHandler#processingInstruction(String,String)
   * @throws SAXException Immediately when this method is called.
   */
  public void processingInstruction(String target, String data) throws SAXException {
    throw new SAXException(InvalidSceneReq.create("Processing instructions not allowed in scene requirements.", locator));
  }

  /**
   * Call of this method triggers an exception.
   * @see ContentHandler#skippedEntity(String)
   * @throws SAXException Immediately when this method is called.
   */
  public void skippedEntity(String name) throws SAXException {
    throw new SAXException(InvalidSceneReq.create("Unknown entity", locator));
  }

  /**
   * We do not need any special processing for the prefix mapping, so we
   * do nothing in this method.
   * @see ContentHandler#startPrefixMapping(String,String)
   */
  public void startPrefixMapping(String prefix, String uri) {}

  /**
   * We do not need any special processing for the prefix mapping, so we
   * do nothing in this method.
   * @see ContentHandler#endPrefixMapping(String)
   */
  public void endPrefixMapping(String prefix) {}

  /**
   * Store the supplied document locator for possible later use.
   * @see ContentHandler#setDocumentLocator(Locator)
   */
  public void setDocumentLocator(Locator locator) {
    this.locator = locator;
  }

  /**
   * Initializes itself when parsing of a new XML document begins.
   * @see ContentHandler#startDocument()
   */
  public void startDocument() {
    description = "";

    reqRooms = new java.util.LinkedList();
    allowedRooms = new java.util.LinkedList();
    constraints = new java.util.LinkedList();
  }

  /**
   * Processes an XML opening tag that has been read.
   * @see ContentHandler#startElement(String,String,String,Attributes)
   * @throws SAXException when some parsing error occurrs.
   */
  public void startElement(String namespaceURI, String localName, String qName,
                           Attributes atts) throws SAXException {
    try {
      switch(state) {
        case 0:
           if (!qName.equalsIgnoreCase("scenereq"))
              throw InvalidSceneReq.create("scenereq expected but '"+qName+"' found", locator);

           library = atts.getValue("library");
           xSize = Integer.parseInt(atts.getValue("xsize"));
           ySize = Integer.parseInt(atts.getValue("ysize"));
           zSize = Integer.parseInt(atts.getValue("zsize"));
           goodScore = Float.parseFloat(atts.getValue("goodscore"));

           if (atts.getIndex("badscore") < 0) {
             badScore = Float.NEGATIVE_INFINITY;
           } else {
             badScore = Float.parseFloat(atts.getValue("badscore"));
           }

           if (atts.getIndex("trashscore") < 0) {
             trashScore = Float.NEGATIVE_INFINITY;
           } else {
             trashScore = Float.parseFloat(atts.getValue("trashscore"));
           }

           if (xSize <= 0 || ySize <= 0 || zSize <= 0)
             throw InvalidSceneReq.create("Invalid scenereq size", locator);

           platform = new boolean[xSize][ySize][zSize];

           state = 1;
           break;

        case 1:
          if (qName.equalsIgnoreCase("description")) {
            state = 2;
          } else if (qName.equalsIgnoreCase("platform")) {
            level = Integer.parseInt(atts.getValue("level"));
            currRow = 0;
            state = 3;
          } else if (qName.equalsIgnoreCase("allplatform")) {
            for (int x = 0; x < xSize; x++)
              for (int y = 0; y < ySize; y++)
                for (int z = 0; z < zSize; z++)
                  platform[x][y][z] = true;
            state = 5;
          } else throw InvalidSceneReq.create("'"+qName+"' unexpected", locator);
          break;

        case 3:
          if (!qName.equalsIgnoreCase("platformrow"))
            throw InvalidSceneReq.create("platformrow expected but '"+qName+"' found", locator);

          if (currRow >= ySize)
            throw InvalidSceneReq.create("Too many platformrows", locator);

          rowData = "";
          state = 4;
          break;

        case 6:
          if (qName.equalsIgnoreCase("platform")) {
            level = Integer.parseInt(atts.getValue("level"));
            currRow = 0;
            state = 3;
          } else if (qName.equalsIgnoreCase("constraint")) {
            constraints.add(new SceneReqConstraint(atts));
            state = 9;
          } else if (qName.equalsIgnoreCase("reqroom")) {
            reqRooms.add(new RequiredRoom(atts));
            state = 8;
          } else if (qName.equalsIgnoreCase("allowroom")) {
            allowedRooms.add(new AllowedRoom(atts));
            state = 7;
          } else throw InvalidSceneReq.create("'"+qName+"' unexpected", locator);
          break;

        default:
          throw InvalidSceneReq.create("'"+qName+"' unexpected", locator);
      }
    } catch (Exception e) {
      throw new SAXException(e);
    }
  }

  /**
   * Processes an XML closing tag that has been read.
   * @see ContentHandler#endElement(String,String,String)
   * @throws SAXException when some parsing error occurrs.
   */
  public void endElement(String namespaceURI, String localName, String qName) throws SAXException {
    try {
      switch(state) {
        case 2:
          if (!qName.equalsIgnoreCase("description"))
            throw InvalidSceneReq.create("End of description expected but end of '"+qName+"' found", locator);
          state = 1;
          break;

        case 3:
          if (!qName.equalsIgnoreCase("platform"))
            throw InvalidSceneReq.create("End of platform expected but end of '"+qName+"' found", locator);
          state = 6;
          break;

        case 4:
          if (!qName.equalsIgnoreCase("platformrow"))
            throw InvalidSceneReq.create("End of platformrow expected but end of '"+qName+"' found", locator);

          rowData = rowData.trim();
          if (rowData.length() != xSize)
            throw InvalidSceneReq.create("Invalid platformrow (bad length)", locator);

          char[] rowChars = rowData.toCharArray();

          for (int x = 0; x < xSize; x++) {
            switch (rowChars[x]) {
              case 'x':
              case 'X':
              case '1':
              case '#':
              case '*':
              case '+':
                platform[x][currRow][level] = true;
                break;

              case '.':
              case '0':
              case ' ':
              case '-':
              case '_':
                platform[x][currRow][level] = false;
                break;

              default:
                throw InvalidSceneReq.create("Invalid platformrow (bad character)", locator);
            }
          }

          currRow++;
          state = 3;
          break;

        case 5:
          if (!qName.equalsIgnoreCase("allplatform"))
            throw InvalidSceneReq.create("End of allplatform expected, but end of '"+qName+"' found", locator);

          state = 6;
          break;

        case 6:
          if (!qName.equalsIgnoreCase("scenereq"))
            throw InvalidSceneReq.create("End of scenereq expected, but end of '"+qName+"' found", locator);
          state = 10;
          break;

        case 7:
          if (!qName.equalsIgnoreCase("allowroom"))
            throw InvalidSceneReq.create("End of allowroom expected, but end of '"+qName+"' found", locator);
          state = 6;
          break;

        case 8:
          if (!qName.equalsIgnoreCase("reqroom"))
            throw InvalidSceneReq.create("End of reqroom expected, but end of '"+qName+"' found", locator);
          state = 6;
          break;

        case 9:
          if (!qName.equalsIgnoreCase("constraint"))
            throw InvalidSceneReq.create("End of constraint expected, but end of '"+qName+"' found", locator);
          state = 6;
          break;

        default:
          throw InvalidSceneReq.create("End of '"+qName+" unexpected", locator);
      }
    } catch (Exception e) {
      throw new SAXException(e);
    }
  }

  /**
   * Processes character data that has been read.
   * @see ContentHandler#characters(char[],int,int)
   * @throws SAXException when some parsing error occurrs.
   */
  public void characters(char[] ch, int start, int length) throws SAXException {
    try {
      switch(state) {
        case 2:
          description = description + String.copyValueOf(ch, start, length);
          break;

        case 4:
          rowData = rowData + String.copyValueOf(ch, start, length);
          break;

        default:
          throw InvalidSceneReq.create("Unexpected character data", locator);
      }
    } catch (Exception e) {
      throw new SAXException(e);
    }
  }

  /**
   * Processes whitespace that has been read, but can be ignored.
   * @see ContentHandler#ignorableWhitespace(char[],int,int)
   * @throws SAXException when some parsing error occurrs.
   */
  public void ignorableWhitespace(char[] ch, int start, int length) throws SAXException {
    if (state == 2 || state == 4)
      characters(ch, start, length);
    // otherwise, ignore this whitespace
  }

  /**
   * Called when end of the XML document has been reached.
   * @see ContentHandler#endDocument()
   * @throws SAXException when some parsing error occurrs.
   */
  public void endDocument() throws SAXException {
    if (state != 10) {
      throw new SAXException(InvalidSceneReq.create("Premature end of input file", locator));
    }

    // prepare the high-level structures
    platformCells = new ScenePlatformCell[xSize][ySize][zSize];
    for (int x = 0; x < xSize; x++)
     for (int y = 0; y < ySize; y++)
      for (int z = 0; z < zSize; z++)
       platformCells[x][y][z] = new ScenePlatformCell(platform[x][y][z]);
  }

  /*----------------------------- ErrorHandler ---------------------------*/

  /**
   * A potentially error situation has been detected. The method prints a
   * warning message on the error output and continues without error.
   * @see ErrorHandler#warning(SAXParseException)
   */
  public void warning(SAXParseException exception) throws SAXException {
    System.err.println("WARNING: "+exception);
  }

  /**
   * An error situation has been detected. The method throws an exception
   * describing the error situation.
   * @see ErrorHandler#error(SAXParseException)
   * @throws SAXException immediately when this method gets called.
   */
  public void error(SAXParseException exception) throws SAXException {
    throw new SAXException(exception);
  }

  /**
   * A fatal error situation has been detected. The method throws an exception
   * describing the error situation.
   * @see ErrorHandler#fatalError(SAXParseException)
   * @throws SAXException immediately when this method gets called.
   */
  public void fatalError(SAXParseException exception) throws SAXException {
    throw new SAXException(exception);
  }

  /*------------------------------- other --------------------------------*/

  /**
   * The default constructor. Creates an empty SceneReq, the values must be
   * filled in later by an external source, or this object can be later used as
   * a ContentHandler (and possibly also as an ErrorHandler) when parsing
   * an XML document.
   */
  public SceneReq() { }

  /**
   * Create the SceneReq and load the specified XML document into it. This constructor
   * creates a XMLReader and parses the specified XML document using itself as
   * content and error handlers. The value of the "org.xml.sax.driver" property
   * specifies the XMLReader reader used to parse the document.
   * @param xmlFile URI of the top-level XML document to be parsed
   * @throws SAXException when parsing the XML document fails
   * @throws java.io.IOException an IO exception from the parser
   * @see XMLReader
   * @see XMLReaderFactory#createXMLReader()
   */
  public SceneReq(String xmlFile) throws SAXException, java.io.IOException {
      XMLReader xmlReader = XMLReaderFactory.createXMLReader();
      xmlReader.setContentHandler(this);
      xmlReader.setErrorHandler(this);
      xmlReader.parse(xmlFile);
  }

  /**
   * Create the SceneReq and load the specified XML file into it. This constructor
   * creates a XMLReader and parses the specified XML file using itself as
   * content and error handlers. The value of the "org.xml.sax.driver" property
   * specifies the XMLReader reader used to parse the file.
   * @param input The input source for the top-level of the XML document.
   * @throws SAXException when parsing the XML document fails
   * @throws java.io.IOException an IO exception from the parser
   * @see XMLReader
   * @see XMLReaderFactory#createXMLReader()
   */
  public SceneReq(InputSource input) throws SAXException, java.io.IOException {
      XMLReader xmlReader = XMLReaderFactory.createXMLReader();
      xmlReader.setContentHandler(this);
      xmlReader.setErrorHandler(this);
      xmlReader.parse(input);
  }

  /*-------------------------------- etc ---------------------------------*/

  /**
   * This method finds the first cell suitable for room placement in the scene
   * platform. The cell coordinates are store into {@link #emptyX}, {@link #emptyY},
   * {@link emptyZ} fields.
   * @return true if an empty cell has been found and the coordinates are stored,
   *         false otherwise (the {@link #platform} contains no <CODE>false<CODE> item)
   */
  public boolean findEmptyCell() {
    for (int z = 0; z < zSize; z++)
     for (int x = 0; x < xSize; x++)
      for (int y = 0; y < ySize; y++)
       if (platformCells[x][y][z].available) {
         emptyX = x;
         emptyY = y;
         emptyZ = z;
         return true;
       }

    return false;
  }

  /**
   * This method returns a string description of this object.
   * @return A string describing this object.
   * @see Object#toString()
   */
  public String toString() {
    String s = "Scene requirements:\nLibrary:\t'"+library+"'\nDescription:\t"+description+"\nPlatform:\t"+xSize+"x"+ySize+"x"+zSize+"\nRequired rooms:\n";
    int i;

    Object[] list;

    list = reqRooms.toArray();
    for (i = 0; i < list.length; i++)
      s = s + "\t" + (RequiredRoom)(list[i]) + "\n";

    s = s + "\nAllowed rooms:\n";

    list = allowedRooms.toArray();
    for (i = 0; i < list.length; i++)
      s = s + "\t" + (AllowedRoom)(list[i]) + "\n";

    s = s + "\nConstraints:\n";

    list = constraints.toArray();
    for (i = 0; i < list.length; i++)
      s = s + "\t" + (SceneReqConstraint)(list[i]) + "\n";

    return s;
  }

  String platformToString() {
    String pl = "";
    for (int z = 0; z < zSize; z++)
     for (int y = 0; y < ySize; y++) {
      for (int x = 0; x < xSize; x++)
       if (platformCells[x][y][z].available) pl = pl + "X"; else pl = pl + ".";
      pl = pl + "\n";
     }
    return pl;
  }
}
