package cz.cvut.felk.cs.gm.sceneautobuilder;

/**
 * Title:        Stavebnice komplexnich 3D scen
 * Description:
 * Copyright:    Copyright (c) 2002
 * Company:
 * @author Petr Kadlec <kadlecp2@fel.cvut.cz>
 * @version 1.1
 */

/** A single cell of a platform. */
class PlatformCell {
  /** Portal presence flags. */
  public final static short PORTAL_NONE  = 0,
                            PORTAL_IN    = 1,
                            PORTAL_OUT   = 2,
                            PORTAL_INOUT = 3;

  /**
   * Is this cell contained in the platform? I.e. in ScenePlatformCell this
   * means the cell is available for a room, in room PlatformCell this
   * means the cell is occupied by the room.
   */
  public boolean available;

  /**
   * Doors on sides of the cell. Index: 0 = up, 1 = right, 2 = down, 3 = left.
   * Contains PORTAL_xxx values.
   */
  public short[] doors = new short[4];

  /**
   * Doors on sides of the cell. Index: 0 = up, 1 = right, 2 = down, 3 = left.
   * Contains PORTAL_xxx values.
   */
  public short[] windows = new short[4];

  /** Stairs in the cell. Index: 0 = upstairs, 1 = downstairs. */
  public boolean[] stairs = new boolean[2];

  /** The default constructor */
  public PlatformCell() { }

  /** Constructor which also sets the {@link #available} field. */
  public PlatformCell(boolean available) {
    this.available = available;
  }

  /**
   * Clones this object.
   * @return A clone of this object.
   */
  public Object clone() {
    PlatformCell pc = new PlatformCell(available);
    pc.doors = (short[])doors.clone();
    pc.windows = (short[])windows.clone();
    pc.stairs = (boolean[])stairs.clone();
    return pc;
  }
}

/** A single cell of a scene platform. */
class ScenePlatformCell extends PlatformCell {
  /** RoomDescription of the room placed into this scene platform cell. */
  public RoomDescription placedRoomDescription;
  /** RoomPlacement of the room placed into this scene platform cell. */
  public RoomPlacement   placedRoomPlacement;

  /** The default constructor. */
  public ScenePlatformCell() {}

  /** Constructor which also sets the {@link #available} field. */
  public ScenePlatformCell(boolean available) {
    this.available = available;
  }

  /**
   * Clones this object.
   * @return A clone of this object.
   */
  public Object clone() {
    ScenePlatformCell pc = new ScenePlatformCell(available);
    pc.doors = (short[])doors.clone();
    pc.windows = (short[])windows.clone();
    pc.stairs = (boolean[])stairs.clone();
    pc.placedRoomDescription = placedRoomDescription;
    pc.placedRoomPlacement = placedRoomPlacement;
    return pc;
  }
}
