package cz.cvut.felk.cs.gm.sceneautobuilder;

/**
 * Title:        Stavebnice komplexnich 3D scen
 * Description:
 * Copyright:    Copyright (c) 2002
 * Company:
 * @author Petr Kadlec <kadlecp2@fel.cvut.cz>
 * @version 1.1
 */

import java.util.List;
import java.util.Stack;
import java.util.Iterator;

/** Exception class for reporting assertion failures. */
class AssertionFailure extends RuntimeException {
  /** The default constructor. */
  public AssertionFailure() {
    super();
  }

  /**
   * Constructor with an error message.
   * @param msg Error message.
   */
  public AssertionFailure(String msg) {
    super(msg);
  }

  /**
   * Assertion without an error message.
   * @param test If test equals false, an AssertionFailure is thrown.
   */
  public static void assert(boolean test) {
    if (!test) throw new AssertionFailure();
  }

  /**
   * Assertion with an error message.
   * @param test If test equals false, an AssertionFailure is thrown.
   * @param msg Message for the possibly thrown AssertionFailure.
   */
  public static void assert(boolean test, String msg) {
    if (!test) throw new AssertionFailure(msg);
  }
}

/**
 * This class represents a group of room types. It allows to note number of uses
 * for each room group and a list of all room types in the group.
 * It provides static methods to retrieve a group with a specified name.
 */
class RoomGroup {
  /**
   * List of all groups used in the program. This list is used when retrieving
   * a group of a given name. The List contains objects of the RoomGroup class.
   */
  static List allGroups = new java.util.LinkedList();

  /**
   * Name (identifier) of the group. The identifier is case-insensitive.
   */
  public String name;
  /**
   * List of all rooms of this group. The List contains objects of the
   * {@link RoomDescription} class.
   */
  public List rooms;

  /**
   * Number of rooms of this type in the scene.
   */
  public int used;

  /**
   * Minimum number of uses of this group's rooms.
   */
  public int min_uses;

  /**
   * Maximum number of uses of this group's rooms.
   */
  public int max_uses;

  /**
   * Score modifier when used.
   */
  public float score;

  /**
   * Score modifier when used &lt; min or &gt; max. This number should be
   * positive, it is subtracted from the score.
   */
  public float scoreBadUsed;

  /**
   * The default constructor.
   */
  public RoomGroup() {
    allGroups.add(this);
    rooms = new java.util.LinkedList();
  }

  /**
   * Constructs the group and assigns it the name.
   * @param name Group identifier
   */
  public RoomGroup(String name) {
    allGroups.add(this);
    this.name = name;
    rooms = new java.util.LinkedList();
  }

  /**
   * Constructs the group, assigns it the name, and inserts the room type
   * to the {@link #rooms} list.
   * @param name Group identifier
   * @param room A room type to be inserted into the rooms list.
   */
  public RoomGroup(String name, RoomDescription room) {
    allGroups.add(this);
    this.name = name;
    rooms = new java.util.LinkedList();
    rooms.add(room);
  }

  /**
   * A finalizer method, manages the {@link #allGroups} list.
   */
  protected void finalize() {
    allGroups.remove(this);
  }

  /**
   * Find a group of the given name. If no group with the name exists, the
   * method returns null.
   * @param name Group identifier of the group to be found. The identifier is
   *        case-insensitive.
   * @return A RoomGroup object of the group with the given name, or null when
   *         no such group exists.
   */
  public static RoomGroup findGroup(String name) {
    java.util.Iterator i = allGroups.listIterator();
    while (i.hasNext()) {
      RoomGroup o = (RoomGroup)(i.next());
      if (o.name.equalsIgnoreCase(name))
         return o;
    }
    return null;
  }

  /**
   * Find a group with the given name and insert the room into its {@link #rooms}
   * list. If no group with the name already exists, the method creates a new
   * one with the room as the only member.
   * @param name Group identifier of the group to be found. The identifier is
   *        case-insensitive.
   * @param room A room that is to be inserted into the group.
   * @return RoomGroup with the given name.
   */
  public static RoomGroup addToGroup(String name, RoomDescription room) {
    RoomGroup g = findGroup(name);
    if (g == null)
      return new RoomGroup(name, room);
    else {
      g.rooms.add(room);
      return g;
    }
  }
}

/**
 * This class is a container for storing coordinates of the placement of a single
 * room. It contains the coordinates, rotation, reference to the room description,
 * and a reference to the proper RoomCompilation.
 */
class RoomPlacement {
  /**
   * Rotation is specified in 90&deg; increments. These constants may not be modified.
   */
  public static final short ROTATION_NONE = 0,
                            ROTATION_90   = 1,
                            ROTATION_180  = 2,
                            ROTATION_270  = 3;

  /** RoomDescription of this room. */
  public RoomDescription room;
  /** Placement coordinates of this room placement. */
  public int x, y, z;

  /** Rotation of the room prior to placement. */
  private short rotation;
  /** Placement coordinates of this room placement, room coordinate system origin. */
  int xo, yo, zo;

  /** Room compilation of the placed room. */
  RoomCompilation roomCompilation;

  /** Delta coordinates for { up, right, down, left, upstairs, downstairs } */
  final static short[] dxs = {  0, +1,  0, -1,  0,  0 },
                       dys = { -1,  0, +1,  0,  0,  0 },
                       dzs = {  0,  0,  0,  0, +1, -1 };

  /**
   * Constructor of the room.
   * @param room RoomDescription of the room this placement wraps.
   * @param x X coordinate onto which the room firstpoint should be placed.
   * @param y Y coordinate onto which the room firstpoint should be placed.
   * @param z Z coordinate onto which the room firstpoint should be placed.
   * @param rotation How many times should be the room be rotated prior to placement.
   */
  public RoomPlacement(RoomDescription room, int x, int y, int z, short rotation) {
    this.room = room;
    setPosition(x, y, z);
    setRotation(rotation);
  }

  /**
   * Set the room rotation.
   * @param rotation New value for the rotation field.
   */
  public void setRotation(short rotation) {
    roomCompilation = room.roomCompilations[rotation];
    xo = x - roomCompilation.firstX;
    yo = y - roomCompilation.firstY;
    zo = z - roomCompilation.firstZ;
    this.rotation = rotation;
  }

  /**
   * Get current value of the room rotation.
   * @return Current rotation value.
   */
  public short getRotation() {
    return rotation;
  }

  /**
   * Sets the room position
   * @param x X coordinate onto which the room firstpoint should be placed.
   * @param y Y coordinate onto which the room firstpoint should be placed.
   * @param z Z coordinate onto which the room firstpoint should be placed.
   */
  public void setPosition(int x, int y, int z) {
    this.x = x;
    this.y = y;
    this.z = z;
    setRotation(rotation);
  }

  /**
   * Helper function checking compatibility of two portals.
   */
  private static boolean checkPortalCompatibility(short t1, short t2) {
    final boolean compatible[][] = {{true,false,false,false},
                                    {false,true,false,true},
                                    {false,false,true,true},
                                    {false,true,true,true}};
    /*if (!compatible[t1][t2])
       System.out.println("Incompatible portals: "+t1+" & "+t2);*/
    return compatible[t1][t2];
  }

  /**
   * Check if this room can be placed into the given scene.
   * @param scenePlatform Scene platform into which should be this room placed.
   * @return Boolean specifying whether the room can be placed into the scene.
   */
  public boolean canBePlaced(ScenePlatformCell[][][] scenePlatform) {
    if (xo < 0 || yo < 0 || zo < 0 ||
        xo + roomCompilation.xSize > scenePlatform.length ||
        yo + roomCompilation.ySize > scenePlatform[0].length ||
        zo + roomCompilation.zSize > scenePlatform[0][0].length) {
        //System.out.println("Unable to place at ["+xo+";"+yo+";"+zo+"] -- out of scene");
        return false;
    }

    for (int xr = 0; xr < roomCompilation.xSize; xr++)
     for (int yr = 0; yr < roomCompilation.ySize; yr++)
      for (int zr = 0; zr < roomCompilation.zSize; zr++)
        if (roomCompilation.platformCells[xr][yr][zr].available) {
          if (!scenePlatform[xo + xr][yo + yr][zo + zr].available) {
            //System.out.println("Unable to place at ["+(xo+xr)+";"+(yo+yr)+";"+(zo+zr)+"] -- not available");
            return false;
          }

          for (int s = 0; s < 2; s++) {
            final int zs = zo + zr + dzs[s + 4];
            if (roomCompilation.platformCells[xr][yr][zr].stairs[s]) {
              if (zs < 0 || zs >= scenePlatform[0][0].length ||
                 (!scenePlatform[xo + xr][yo + yr][zs].available && scenePlatform[xo + xr][yo + yr][zs].placedRoomDescription == null)) {
                //System.out.println("Unable to place at ["+(xo+xr)+";"+(yo+yr)+";"+(zo+zr)+"] -- STAIRS going outside");
                return false;
              }
              if (!scenePlatform[xo + xr][yo + yr][zs].available && scenePlatform[xo + xr][yo + yr][zs].placedRoomDescription != null) {
                if (!scenePlatform[xo + xr][yo + yr][zs].stairs[1 - s]) {
                   //System.out.println("Unable to place at ["+(xo+xr)+";"+(yo+yr)+";"+(zo+zr)+"] -- No STAIRS in the other room");
                   return false;
                }
              }
            }
          }

          for (int s = 0; s < 4; s++) {
            final int xs = xo + xr + dxs[s];
            final int ys = yo + yr + dys[s];
            if (xs < 0 || ys < 0 || xs >= scenePlatform.length || ys >= scenePlatform[0].length ||
                (!scenePlatform[xs][ys][zo + zr].available && scenePlatform[xs][ys][zo + zr].placedRoomDescription == null)) {
              // portal going outside
              if (roomCompilation.platformCells[xr][yr][zr].doors[s] == PlatformCell.PORTAL_IN) {
                //System.out.println("Unable to place at ["+(xo+xr)+";"+(yo+yr)+";"+(zo+zr)+"] -- DOOR/IN going outside");
                return false;
              }
              if (roomCompilation.platformCells[xr][yr][zr].windows[s] == PlatformCell.PORTAL_IN) {
                //System.out.println("Unable to place at ["+(xo+xr)+";"+(yo+yr)+";"+(zo+zr)+"] -- WINDOW/IN going outside");
                return false;
              }
            } else {
              // portal inside
              short ptype = roomCompilation.platformCells[xr][yr][zr].doors[s];
              int   oppside = (s + 2) & 3;
              if (ptype == PlatformCell.PORTAL_OUT) {
                //System.out.println("Unable to place at ["+(xo+xr)+";"+(yo+yr)+";"+(zo+zr)+"] -- DOOR/OUT going inside");
                return false;
              }
              if (!(scenePlatform[xs][ys][zo+zr].available || checkPortalCompatibility(ptype, scenePlatform[xs][ys][zo+zr].doors[oppside]))) {
                //System.out.println("Unable to place at ["+(xo+xr)+";"+(yo+yr)+";"+(zo+zr)+"] -- DOOR to "+s+"/"+oppside+" incompatible with neighbor");
                return false;
              }
              ptype = roomCompilation.platformCells[xr][yr][zr].windows[s];
              if (ptype == PlatformCell.PORTAL_OUT) {
                //System.out.println("Unable to place at ["+(xo+xr)+";"+(yo+yr)+";"+(zo+zr)+"] -- WINDOW/OUT going inside");
                return false;
              }
              if (!(scenePlatform[xs][ys][zo+zr].available || checkPortalCompatibility(ptype, scenePlatform[xs][ys][zo+zr].windows[oppside]))) {
                //System.out.println("Unable to place at ["+(xo+xr)+";"+(yo+yr)+";"+(zo+zr)+"] -- WINDOW to "+s+"/"+oppside+" incompatible with neighbor");
                return false;
              }
            }
          }
        }

    return true;
  }

  /**
   * Place the room into the scene.
   * @param scenePlatform Scene platform into which should be this room placed.
   */
  public void placeTo(ScenePlatformCell[][][] scenePlatform) {
    for (int xr = 0; xr < roomCompilation.xSize; xr++)
     for (int yr = 0; yr < roomCompilation.ySize; yr++)
      for (int zr = 0; zr < roomCompilation.zSize; zr++)
        if (roomCompilation.platformCells[xr][yr][zr].available) {
          ScenePlatformCell pc = scenePlatform[xo + xr][yo + yr][zo + zr];
          pc.available = false;
          pc.placedRoomDescription = room;
          pc.placedRoomPlacement = this;
          pc.doors = roomCompilation.platformCells[xr][yr][zr].doors;
          pc.windows = roomCompilation.platformCells[xr][yr][zr].windows;
          pc.stairs = roomCompilation.platformCells[xr][yr][zr].stairs;
        }
  }

  /**
   * Undo the placement of the room into scene.
   * @param scenePlatform Scene platform into which has this room been placed.
   */
  public void unplaceTo(ScenePlatformCell[][][] scenePlatform) {
    for (int xr = 0; xr < roomCompilation.xSize; xr++)
     for (int yr = 0; yr < roomCompilation.ySize; yr++)
      for (int zr = 0; zr < roomCompilation.zSize; zr++)
        if (roomCompilation.platformCells[xr][yr][zr].available) {
          ScenePlatformCell pc = scenePlatform[xo + xr][yo + yr][zo + zr];
          pc.available = true;
          pc.placedRoomDescription = null;
          pc.placedRoomPlacement = null;
        }
  }

  /**
   * This function computes the value of the constraints referencing this
   * room.
   * @param currSolution The current solution, containing all placed rooms.
   * @return Score of all constraints referencing this room.
   */
  public float evaluateConstraints(Solution currSolution) {
    float result = 0;
    //System.out.println("Evalutaing constraints against "+room);
    Iterator roomI = currSolution.rooms.iterator();
    while (roomI.hasNext()) {
      RoomPlacement refRoom = (RoomPlacement) roomI.next();
      if (refRoom.room.group.equalsIgnoreCase(room.group)) continue; // no constraints against the same group!
      //System.out.println("  Room: "+refRoom.room);
      Iterator constraintI = refRoom.room.constraints.iterator();
      while (constraintI.hasNext()) {
        RoomConstraint constraint = (RoomConstraint) constraintI.next();
        //System.out.println("    Constraint: "+constraint);
        if (constraint.from.equalsIgnoreCase(room.group)) {
          result += constraint.evaluate(refRoom, this);
          //System.out.println("      ...current score = " + result);
        }
      }

      Iterator thisConstraintI = room.constraints.iterator();
      while (thisConstraintI.hasNext()) {
        RoomConstraint thisConstraint = (RoomConstraint) thisConstraintI.next();
        //System.out.println("    Local constraint: "+thisConstraint);
        if (thisConstraint.from.equalsIgnoreCase(refRoom.room.group)) {
          result += thisConstraint.evaluate(this, refRoom);
          //System.out.println("      ...current score = " + result);
        }
      }
    }
    return result;
  }

  /**
   * Clones this object.
   * @return A clone of this object.
   */
  public Object clone() {
    return new RoomPlacement(room, x, y, z, rotation);
  }

  /**
   * This method returns a string description of this object.
   * @return A string describing this object.
   * @see Object#toString()
   */
  public String toString() {
    return room + " placed onto ["+x+";"+y+";"+z+"], rotation = " + rotation + "\n"; // i.e. origin=["+xo+";"+yo+";"+zo+"]\n";
  }
}

/**
 * This class is a container for one solution, i.e. a list of rooms with their
 * respective placements.
 */
class Solution {
  /**
   * This stack contains all rooms in the solution. The stack contains
   * instances of RoomPlacement.
   */
  public Stack rooms;

  /** Score of this solution. */
  public float score;

  /** The scene requirements used in this solution. */
  public SceneReq sceneReq;

  /** The default constructor. */
  public Solution() {
    rooms = new Stack();
  }

  /**
   * Clones this object. The <CODE>rooms</CODE> of the clone is a new Stack, containing
   * clones of the original RoomPlacement objects.
   */
  public Object clone() {
    Object[] oldRooms = rooms.toArray();
    Solution clone = new Solution();
    clone.rooms = new Stack();
    clone.rooms.ensureCapacity(oldRooms.length);
    for (int i = 0; i < oldRooms.length; i++)
      clone.rooms.push(((RoomPlacement)oldRooms[i]).clone());
    clone.score = this.score;
    clone.sceneReq = this.sceneReq;
    return clone;
  }

  /** Returns string representation of this object. */
  public String toString() {
    String s = "Solution, score = "+score+"\n";
    for (int i = 0; i < rooms.size(); i++)
      s = s + ((RoomPlacement)rooms.elementAt(i));
    return s;
  }
}

/**
 * This class is a wrapper for the main scene solving algorithm. Note that
 * one class instance may NOT be used for solving more problems!
 */
class Solver {
  /**
   * If score of a solution is equal or bigger than returnAtScore, the
   * solution is returned without looking for some better.
   */
  public float returnAtScore = 0;
  /**
   * If score of a solution is equal or worse than tooLowScore, the solution
   * is not considered valid.
   */
  public float tooLowScore = Float.NEGATIVE_INFINITY;
  /**
   * If a room placement would make the current solution equal or worse than
   * trashScore, the room is not placed there.
   */
  public float trashScore = Float.NEGATIVE_INFINITY;

  /** Number of remaining rooms to be placed according to the constraints. */
  private int remainingMinRooms;

  /** Score of the current solution state. */
  private float positiveScore;
  private float negativeScore;

  /** Initializes the library. */
  private void initLibrary(SceneReq sceneReq, Library library) throws InvalidSceneReq {
    // create all groups
    Iterator i = library.rooms.iterator();
    while (i.hasNext()) {
      RoomDescription room = (RoomDescription) i.next();
      RoomGroup.addToGroup(room.group, room);
    }

    // init groups' limits
    remainingMinRooms = 0;
    i = sceneReq.reqRooms.iterator();
    while (i.hasNext()) {
      RequiredRoom room = (RequiredRoom) i.next();
      RoomGroup group = RoomGroup.findGroup(room.name);
      if (group == null) throw new InvalidSceneReq("Unknown group identifier (" + room.name + ")");
      group.min_uses = room.min;
      group.max_uses = room.max;
      group.score = 0;
      remainingMinRooms += room.min;
    }

    i = sceneReq.allowedRooms.iterator();
    while (i.hasNext()) {
      AllowedRoom room = (AllowedRoom) i.next();
      RoomGroup group = RoomGroup.findGroup(room.name);
      if (group == null) throw new InvalidSceneReq("Unknown group identifier (" + room.name + ")");
      group.min_uses = 0;
      group.max_uses = Integer.MAX_VALUE;
      group.score = room.score;
    }
  }

  /** The SceneReq used by the solver. */
  private SceneReq sceneReq;

  /** Has a solution been found? */
  private boolean solutionFound;
  private Solution currSolution;
  public  Solution bestSolution;

  /**
   * The main recursive solving procedure.
   * @param emptyX X coordinate of the first empty field in the scene.
   * @param emptyY Y coordinate of the first empty field in the scene.
   * @param emptyZ Z coordinate of the first empty field in the scene.
   */
  private void recursiveSolve(int emptyX, int emptyY, int emptyZ) {
      Iterator gI = RoomGroup.allGroups.iterator();
      while (gI.hasNext()) {
        RoomGroup group = (RoomGroup) gI.next();
        if (group.used >= group.max_uses) continue;
        if (group.min_uses > group.used) remainingMinRooms--;
        group.used++;

        if (group.score > 0) positiveScore += group.score;
        else negativeScore -= group.score;

        Iterator rI = group.rooms.iterator();
        while (rI.hasNext()) {
          RoomDescription room = (RoomDescription) rI.next();
          RoomPlacement roomPlace = new RoomPlacement(room, emptyX, emptyY, emptyZ, RoomPlacement.ROTATION_NONE);
          /** @todo (SPEED OPTIMIZATION) Do not do a "new RoomPlacement" in the main loop... But HOW? Many changes would be required. */
          /** @todo FIXME: (SPEED OPTIMIZATION) If scene has a "doorsout/windowsout max" constraint, check it here, so that no more doorsout/windowsout get placed. */
          currSolution.rooms.push(roomPlace);

          for (short rotation = 0; rotation < 4; rotation++) {
            roomPlace.setRotation(rotation);
            //System.out.println("ROTATED ROOM:\n"+roomPlace.roomCompilation);
            //System.out.println("BEFORE PLACEMENT:\n"+sceneReq.platformToString());
            //System.out.print("["+emptyX+";"+emptyY+";"+emptyZ+"] "+room+" at ["+emptyX+";"+emptyY+";"+emptyZ+"], rotation="+rotation+"...");
            if (roomPlace.canBePlaced(sceneReq.platformCells)) {
              //System.out.println("yes");

              // evaluate the constraints
              float posScoreBeforeConstraints = positiveScore,
                    negScoreBeforeConstraints = negativeScore;

              float constraintsScore = roomPlace.evaluateConstraints(currSolution);
              if (constraintsScore > 0) positiveScore += constraintsScore;
              else negativeScore -= constraintsScore;

              if (-negativeScore <= trashScore) {
                //System.out.println("...constrained out");
                positiveScore = posScoreBeforeConstraints;
                negativeScore = negScoreBeforeConstraints;
                continue;
              }

              roomPlace.placeTo(sceneReq.platformCells);

              //System.out.println("PLACED:\n"+sceneReq.platformToString());
              // find next empty cell
              if (!sceneReq.findEmptyCell()) {
                // no empty space -- test the solution for validity

                // add all score modifiers of the rooms having bad used value.
                Iterator bgI = RoomGroup.allGroups.iterator();
                while (bgI.hasNext()) {
                  RoomGroup bg = (RoomGroup)bgI.next();
                  if (bg.used < bg.min_uses || bg.used > bg.max_uses) negativeScore += bg.scoreBadUsed;
                }

                // evaluate the scene constraints
                Iterator scI = sceneReq.constraints.iterator();
                while (scI.hasNext()) {
                  SceneReqConstraint sc = (SceneReqConstraint)scI.next();
                  constraintsScore = sc.evaluate(currSolution);
                  if (constraintsScore > 0) positiveScore += constraintsScore;
                  else negativeScore -= constraintsScore;
                }

                // compute the resulting score
                if (negativeScore <= Float.NEGATIVE_INFINITY) currSolution.score = Float.NEGATIVE_INFINITY;
                else currSolution.score = positiveScore - negativeScore;

                //System.out.println("No more empty cells. Score = "+positiveScore+" - "+negativeScore+" = "+currSolution.score);

                if (currSolution.score > tooLowScore && (bestSolution == null || bestSolution.score < currSolution.score)) {
                  bestSolution = (Solution)currSolution.clone();
                }
              } else recursiveSolve(sceneReq.emptyX, sceneReq.emptyY, sceneReq.emptyZ);

              // if best possible, return (branch-and-bound)
              if (bestSolution != null && bestSolution.score >= returnAtScore) return;

              // Restore saved score from before updating constraints
              positiveScore = posScoreBeforeConstraints;
              negativeScore = negScoreBeforeConstraints;

              //System.out.println("["+emptyX+";"+emptyY+";"+emptyZ+"] "+room+" unplaced.");
              roomPlace.unplaceTo(sceneReq.platformCells);
              //System.out.println("AFTER UNPLACING:\n"+sceneReq.platformToString());
            } //else System.out.println("no");
          }

          currSolution.rooms.pop();
        }

        if (group.score > 0) positiveScore -= group.score;
        else negativeScore += group.score;

        group.used--;
        if (group.min_uses > group.used) remainingMinRooms++;
      }
  }

  /**
   * Interface for the Solver class. Solves the scene.
   * @param sceneReq SceneReq object containing the scene requirements.
   * @param library Library object containing the room library.
   * @return Has a solution been found?
   * @throws InvalidSceneReq when an invalid sceneReq parameter has been passed.
   */
  public boolean Solve(SceneReq sceneReq, Library library) throws InvalidSceneReq {
    initLibrary(sceneReq, library);

    solutionFound = false;
    this.sceneReq = sceneReq;

    returnAtScore = sceneReq.goodScore;
    tooLowScore = sceneReq.badScore;
    trashScore = sceneReq.trashScore;

    currSolution = new Solution();
    currSolution.sceneReq = sceneReq;
    bestSolution = null;
    positiveScore = 0.0f;
    negativeScore = 0.0f;
    if (!sceneReq.findEmptyCell()) return true;
    recursiveSolve(sceneReq.emptyX, sceneReq.emptyY, sceneReq.emptyZ);
    solutionFound = bestSolution != null;

    return solutionFound;
  }
}
