package cz.cvut.felk.cs.gm.sceneautobuilder;

/**
 * Title:        Stavebnice komplexnich 3D scen
 * Description:
 * Copyright:    Copyright (c) 2002
 * Company:
 * @author Petr Kadlec <kadlecp2@fel.cvut.cz>
 * @version 1.1
 */

/**
 * @todo Some automatic relaxation?
 * @todo (MAYBE) Change the program+DTD not to use any default values, use
 *               #IMPLIED only, code the defaults into the program, the XML
 *               files would be standalone then.
 *
 * @todo (TESTING) Test: all z-related, neighbour roomconstraint, connected roomconstraint, maybe score atts.
 */

import java.net.URL;
import java.util.Iterator;

import cv97.SceneGraph;
import cv97.node.*;

/**
 * The main program class containing the <CODE>main</CODE> method.<BR>
 * Program defines property <CODE>cz.cvut.felk.cs.gm.sceneautobuilder.outfmt</CODE> that
 * may have one of values VRML, X3D (XML also accepted) and selects output format.<BR>
 * Return code is: 0 when a valid solution has been found, output file created.
 * 1 when the scene does not have a valid solution. 2 when the program was started
 * illegally (invalid parameters, etc.) 3 when an uncaught exception has been thrown.
 */
public class BuildScene {
  /** Program version string. */
  public static final String version = "SceneAutoBuilder v1.1 (c) Petr Kadlec, 2002-2003";

  /**
   * The main program method.
   * @param args Command-line arguments
   */
  public static void main(String[] args) {
    try {
      boolean outputInVRML = true;    // false == output in X3D

      System.err.println(version);

      // ** check and process parameters, properties, etc. **
      if (args.length != 2) {
        System.err.println("Usage: java BuildScene inputscript outputfile");
        System.exit(2);
      }

      if (System.getProperty("org.xml.sax.driver") == null)
        System.setProperty("org.xml.sax.driver", "org.apache.xerces.parsers.SAXParser");

      String outFormat = System.getProperty("cz.cvut.felk.cs.gm.sceneautobuilder.outfmt", "vrml");
      if (outFormat.equalsIgnoreCase("vrml")) outputInVRML = true;
      else if (outFormat.equalsIgnoreCase("x3d") || outFormat.equalsIgnoreCase("xml")) outputInVRML = false;
      else {
        System.err.println("Invalid value of cz.cvut.felk.cs.gm.sceneautobuilder.outfmt property. VRML or X3D expected.");
        System.exit(2);
      }
      String includeFile = System.getProperty("cz.cvut.felk.cs.gm.sceneautobuilder.includefile");

      // ** read and process input files **
      SceneReq sceneReq = new SceneReq(args[0]);
      Library library = new Library(sceneReq.library);

      //System.out.println(sceneReq);
      //System.out.println(library);

      // ** run the main generation process **
      Solver solver = new Solver();
      System.err.print("Solving...");
      if (!solver.Solve(sceneReq, library)) {
        System.err.println("Sorry, the scene does not have a valid solution.\n");
        System.exit(1);
      }
      System.err.println("OK, best score: "+solver.bestSolution.score);

      // ** create output **
      //System.out.println("The best solution:\n"+solver.bestSolution);

      System.err.println("Loading library file...");
      SceneGraph libSceneGraph = new SceneGraph();
      if (library.URL.indexOf("://") < 0)
        libSceneGraph.load(library.URL);          // filename
      else
        libSceneGraph.load(new URL(library.URL)); // URL

      System.err.println("Creating result scene...");
      SceneGraph resultSceneGraph = new SceneGraph();

      // -- add WorldInfo --
      WorldInfoNode worldInfo = new WorldInfoNode();
      worldInfo.setTitle(sceneReq.description);
      worldInfo.addInfo("This file has been created with " + version);
      worldInfo.addInfo("Compiled at " + new java.util.Date() + ", used scene description file: '" + args[0] + "'");
      worldInfo.addInfo("Solution score: "+solver.bestSolution.score);
      resultSceneGraph.addNode(worldInfo);

      // -- add include file if specified --
      if (includeFile != null) {
        resultSceneGraph.add(includeFile);
      }

      // -- add all rooms --
      Iterator rpI = solver.bestSolution.rooms.iterator();
      while (rpI.hasNext()) {
        RoomPlacement room = (RoomPlacement)rpI.next();

        //System.out.println(room.room.object+" ...");
        TransformNode transform = new TransformNode();

        switch (room.getRotation() & 3) {
          case 0:
               transform.addTranslation(library.xScale * room.xo, library.yScale * room.zo, library.zScale * room.yo);
               break;

          case 1:
               transform.addTranslation(library.xScale * (room.xo + room.roomCompilation.xSize), library.yScale * room.zo, library.zScale * room.yo);
               break;

          case 2:
               transform.addTranslation(library.xScale * (room.xo + room.roomCompilation.xSize), library.yScale * room.zo, library.zScale * (room.yo + room.roomCompilation.ySize));
               break;

          case 3:
               transform.addTranslation(library.xScale * room.xo, library.yScale * room.zo, library.zScale * (room.yo + room.roomCompilation.ySize));
               break;
        }
        transform.addRotation(0, -1, 0, (float)(Math.PI / 2 * room.getRotation()));


        Node roomLibNode = libSceneGraph.findNodeByName(room.room.object);
        if (roomLibNode == null)
           throw new InvalidLibrary("The library does not contain an object named '" + room.room.object +"'");

        transform.addChildNode(roomLibNode.cloneWithChildNodes());

        resultSceneGraph.addNode(transform);
      }

      // -- write the output file --
      System.err.println("Writing output file...");

      if (outputInVRML)
        resultSceneGraph.saveVRML(args[1]);
      else
        resultSceneGraph.saveXML(args[1]);

      // ** close all and finish **
      libSceneGraph.stop();
      resultSceneGraph.stop();

      System.err.println("Done");
      System.exit(0);

    } catch (Exception e) {
      System.out.println(e);
      //e.printStackTrace();
      System.exit(3);
    }
  }
}
